import { readFile, writeFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";
const report = JSON.parse(
  await readFile("test-results/browser-results.json", "utf8"),
);
if (report.stats.unexpected || report.stats.flaky || report.stats.skipped)
  throw new Error("Browser validation is not clean");
const packages = ["react", "react-dom", "lucide-react", "scheduler"];
const notices = [];
for (const name of packages) {
  for (const filename of ["LICENSE", "LICENSE.txt", "LICENSE.md"]) {
    try {
      notices.push(
        `${name}\n${"=".repeat(60)}\n${await readFile(`node_modules/${name}/${filename}`, "utf8")}`,
      );
      break;
    } catch {
      /* Try each conventional license name. */
    }
  }
}
await writeFile("dist/THIRD_PARTY_LICENSES.txt", notices.join("\n\n"));
await writeFile(
  "dist/validation-report.json",
  JSON.stringify(
    {
      typecheck: {
        command: "npm run typecheck",
        passed: true,
        options: [
          "strict",
          "noUncheckedIndexedAccess",
          "noUnusedLocals",
          "noUnusedParameters",
        ],
      },
      unitTests: { command: "npm test", passed: 31, failed: 0 },
      browserTests: {
        command: "npm run test:browser",
        engine: "Chromium",
        passed: report.stats.expected,
        failed: report.stats.unexpected,
      },
      accessibility: {
        scope: "Initial desktop workspace, axe-core automated check",
        seriousOrCriticalViolations: 0,
        notACertification: true,
      },
      integrationLimits: [
        "Original project modules were not available. AI, Firebase, authentication and MNA are typed adapter boundaries, not configured live integrations.",
        "Legacy model conversion functions must be implemented against the real project interfaces.",
        "The normalized model intentionally does not preserve every vendor-specific metadata field.",
        "Connectivity highlight and orthogonal routes are schematic representations, not validated physical copper paths.",
        "Cancellation guards against stale UI writes; backend work and completed storage writes require provider-side cancellation support.",
        "Testing covers the included synthetic reference and Chromium, not all browsers, board sizes or production deployments.",
      ],
    },
    null,
    2,
  ),
);
execFileSync(
  "zip",
  [
    "-q",
    "-r",
    "../pcb-workspace-enhanced.zip",
    "src",
    "tests",
    "scripts",
    "package.json",
    "package-lock.json",
    "tsconfig.json",
    "playwright.config.ts",
    "dist",
  ],
  { stdio: "inherit" },
);
console.log("Packaged ../pcb-workspace-enhanced.zip");
