import { build } from "esbuild";
import { mkdir, writeFile } from "node:fs/promises";
const result = await build({
  entryPoints: ["src/demo.tsx"],
  bundle: true,
  write: false,
  outdir: "dist",
  minify: true,
  target: ["es2022"],
  jsx: "automatic",
  define: { "process.env.NODE_ENV": '"production"' },
});
const js =
  result.outputFiles.find((file) => file.path.endsWith(".js"))?.text ?? "";
const css =
  result.outputFiles.find((file) => file.path.endsWith(".css"))?.text ?? "";
if (!js || !css) throw new Error("Build did not produce JavaScript and CSS");
await mkdir("dist", { recursive: true });
const html = `<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PCB Vision — Interactive Workspace</title><style>html,body{margin:0;min-height:100%;background:#050b12}body{font-family:system-ui} ${css}</style></head><body><div id="root"></div><script>${js.replace(/<\/script/gi, "<\\/script")}</script></body></html>`;
await writeFile("dist/pcb-workspace-demo.html", html);
console.log(
  `Built self-contained demo (${Math.round(Buffer.byteLength(html) / 1024)} KB). No external assets or network dependencies.`,
);
