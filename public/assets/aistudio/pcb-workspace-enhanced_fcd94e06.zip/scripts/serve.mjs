import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
const html = await readFile(
  new URL("../dist/pcb-workspace-demo.html", import.meta.url),
);
const port = Number(process.env.PORT || 4173);
createServer((_req, res) => {
  res.writeHead(200, {
    "Content-Type": "text/html; charset=utf-8",
    "Cache-Control": "no-store",
  });
  res.end(html);
}).listen(port, "127.0.0.1", () =>
  console.log(`Demo: http://127.0.0.1:${port}`),
);
