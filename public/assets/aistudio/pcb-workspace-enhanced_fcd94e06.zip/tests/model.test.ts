import test from "node:test";
import assert from "node:assert/strict";
import {
  addPart,
  auditBoard,
  branches,
  connectedPartPath,
  decodeBoard,
  EMPTY_BOARD,
  importBoard,
  movePart,
  normalizeBox,
  normalizeNetName,
  pinPoint,
  reconcileNets,
  removePart,
  resolveProbe,
  routeNet,
  serializeBoard,
  terminalId,
  UNASSIGNED,
  updatePin,
} from "../src/pcbModel";
import { demoBoard } from "../src/demoBoard";
import { reduceHistory, type HistoryState } from "../src/useBoardHistory";
import { voltageFor } from "../src/pcbServices";
import { createHybridVisionAdapter } from "../src/createHybridVisionAdapter";
const board = () => structuredClone(demoBoard);

test("normalizes net names consistently", () => {
  assert.equal(normalizeNetName("  net 5v "), "NET_5V");
  assert.equal(normalizeNetName(" "), UNASSIGNED);
});
test("boxes are ordered, finite, clamped, and non-empty", () => {
  assert.deepEqual(
    normalizeBox({ xmin: 1200, ymin: 1001, xmax: 1000, ymax: -20 }),
    { xmin: 999, ymin: 0, xmax: 1000, ymax: 1000 },
  );
});
test("rejects malformed and unrelated imported projects", () => {
  for (const value of [
    null,
    [],
    {},
    { board: null },
    { components: "wrong", nets: [] },
  ])
    assert.throws(() => decodeBoard(value));
  assert.throws(() => importBoard("{bad json"));
});
test("rejects future schema versions", () => {
  assert.throws(
    () => importBoard(JSON.stringify({ schemaVersion: 2, board: board() })),
    /Unsupported/,
  );
});
test("project roundtrip preserves normalized model and geometry", () => {
  const before = decodeBoard(board());
  assert.deepEqual(importBoard(serializeBoard(before)), before);
});
test("rejects duplicate component references", () => {
  const b = board();
  b.components.push(b.components[0]!);
  assert.throws(() => decodeBoard(b), /Duplicate component/);
});
test("rejects duplicate pin numbers", () => {
  const b = board();
  b.components[0]!.pinSpecs.push(b.components[0]!.pinSpecs[0]!);
  assert.throws(() => decodeBoard(b), /Duplicate pin/);
});
test("rejects duplicate net names after normalization", () => {
  const b = board();
  b.nets.push({ ...b.nets[0]!, name: " net vbat " });
  assert.throws(() => decodeBoard(b), /Duplicate normalized/);
});
test("rejects invalid geometry instead of silently making fake boxes", () => {
  const b = board();
  b.components[0]!.bbox.xmin = Number.NaN;
  assert.throws(() => decodeBoard(b), /Invalid box coordinate/);
});
test("relink removes old terminal and adds new terminal without orphan membership", () => {
  const b = updatePin(board(), "J1", 1, { connectedNetId: " NET_NEW " });
  assert.equal(
    b.nets
      .find((n) => n.name === "NET_VBAT")!
      .connectedComponentRefs.includes("J1"),
    false,
  );
  assert.deepEqual(
    b.nets.find((n) => n.name === "NET_NEW")!.connectedTerminalIds,
    [terminalId("J1", 1)],
  );
});
test("component remains on its old net if another pin still uses it", () => {
  let b = updatePin(board(), "J1", 2, { connectedNetId: "NET_VBAT" });
  b = updatePin(b, "J1", 1, { connectedNetId: "NET_NEW" });
  assert.equal(
    b.nets
      .find((n) => n.name === "NET_VBAT")!
      .connectedComponentRefs.includes("J1"),
    true,
  );
  assert.deepEqual(
    b.nets
      .find((n) => n.name === "NET_VBAT")!
      .connectedTerminalIds.filter((id) => id.startsWith("J1-")),
    ["J1-2"],
  );
});
test("unassigning a pin does not create a real unassigned net", () => {
  const b = updatePin(board(), "J1", 1, { connectedNetId: "" });
  assert.equal(
    b.nets.some((n) => n.name === UNASSIGNED),
    false,
  );
});
test("changing a pin invalidates technician sign-off and rejects nonfinite voltage", () => {
  const b = board();
  b.components[0]!.verificationStatus = "VERIFIED";
  const next = updatePin(b, "J1", 1, { nominalVoltage: Infinity });
  assert.equal(next.components[0]!.verificationStatus, "UNVERIFIED");
  assert.equal(next.components[0]!.pinSpecs[0]!.nominalVoltage, 12.6);
});
test("part removal clears every terminal reference and stale hotspot ownership", () => {
  const b = removePart(board(), "D1");
  assert.equal(
    b.components.some((p) => p.refDes === "D1"),
    false,
  );
  assert.ok(
    b.nets.every(
      (n) =>
        !n.connectedComponentRefs.includes("D1") &&
        n.connectedTerminalIds.every((t) => !t.startsWith("D1-")),
    ),
  );
  assert.equal(b.hotspots[0]!.suspectComponentRef, undefined);
});
test("generated component references remain unique after deletions", () => {
  let b = board();
  for (let i = 0; i < 25; i++) b = addPart(b, "RESISTOR").board;
  b = removePart(b, "R2");
  b = addPart(b, "RESISTOR").board;
  assert.equal(
    new Set(b.components.map((p) => p.refDes)).size,
    b.components.length,
  );
});
test("generic templates do not claim verified manufacturer pinouts", () => {
  const { board: b, ref } = addPart(board(), "MOSFET_DRIVER");
  const p = b.components.find((p) => p.refDes === ref)!;
  assert.equal(p.verificationStatus, "UNVERIFIED");
  assert.ok(p.pinSpecs.every((pin) => pin.connectedNetId === UNASSIGNED));
});
test("moving a part moves only matching terminal geometry on the matching net", () => {
  const b = board();
  const part = b.components[0]!;
  const pt = pinPoint(part, 0);
  b.nets[0]!.tracePoints = [pt, { x: pt.x + 50, y: pt.y + 50 }];
  const before = structuredClone(b);
  const after = movePart(b, part.refDes, {
    xmin: 85,
    ymin: 230,
    xmax: 220,
    ymax: 440,
  });
  assert.deepEqual(branches(after.nets[0]!)[0]![0], {
    x: pt.x + 10,
    y: pt.y + 10,
  });
  assert.deepEqual(
    branches(after.nets[0]!)[0]![1],
    before.nets[0]!.tracePoints[1],
  );
  assert.deepEqual(b, before, "move must not mutate its input");
});
test("resizing remaps terminal-attached trace vertices", () => {
  const b = board();
  const part = b.components[0]!;
  b.nets[0]!.tracePoints = [pinPoint(part, 0)];
  const after = movePart(b, part.refDes, {
    ...part.bbox,
    ymax: part.bbox.ymax + 60,
  });
  assert.deepEqual(
    branches(after.nets[0]!)[0]![0],
    pinPoint(after.components[0]!, 0),
  );
});
test("probe resolves current geometry, not stale captured coordinates", () => {
  const b = board();
  const target = { compRefDes: "J1", pinNumber: 1 };
  const before = resolveProbe(b, target)!;
  const next = movePart(b, "J1", { xmin: 85, ymin: 230, xmax: 220, ymax: 440 });
  assert.notDeepEqual(resolveProbe(next, target)!.point, before.point);
  assert.equal(resolveProbe(removePart(next, "J1"), target), null);
});
test("routing is orthogonal and never automatically verified", () => {
  const b = routeNet(board(), "NET_GND");
  const net = b.nets.find((n) => n.name === "NET_GND")!;
  for (const branch of branches(net))
    for (let i = 1; i < branch.length; i++)
      assert.ok(
        branch[i]!.x === branch[i - 1]!.x || branch[i]!.y === branch[i - 1]!.y,
      );
  assert.equal(net.verificationStatus, "UNVERIFIED");
  assert.equal(net.isComplete, false);
});
test("connectivity search follows assigned nets and rejects disconnected parts", () => {
  assert.ok(connectedPartPath(board(), "J1", "TP1"));
  const added = addPart(board(), "TEST_POINT");
  assert.equal(connectedPartPath(added.board, "J1", added.ref), null);
  assert.equal(connectedPartPath(board(), "MISSING", "U1"), null);
});
test("audit exposes unassigned pins without declaring a physical fault", () => {
  const added = addPart(board(), "TEST_POINT");
  assert.ok(
    auditBoard(added.board).some(
      (f) => f.targetCompRef === added.ref && f.severity === "INFO",
    ),
  );
});
test("reconciliation is idempotent", () => {
  const b = reconcileNets(board());
  assert.deepEqual(reconcileNets(b), b);
});
test("history groups many drag frames into a single undoable transaction", () => {
  const initial = { board: board(), imageDataUrl: null };
  let state: HistoryState = {
    past: [],
    present: initial,
    future: [],
    revision: 0,
  };
  for (let i = 0; i < 30; i++)
    state = reduceHistory(state, {
      type: "preview",
      document: { ...initial, board: { ...initial.board, title: `Drag ${i}` } },
    });
  state = reduceHistory(state, { type: "finish", baseline: initial });
  assert.equal(state.past.length, 1);
  const title = state.present.board.title;
  state = reduceHistory(state, { type: "undo" });
  assert.equal(state.present, initial);
  state = reduceHistory(state, { type: "redo" });
  assert.equal(state.present.board.title, title);
});
test("new edits clear redo and history never exceeds its limit", () => {
  const initial = { board: board(), imageDataUrl: null };
  let state: HistoryState = {
    past: [],
    present: initial,
    future: [],
    revision: 0,
  };
  for (let i = 0; i < 60; i++)
    state = reduceHistory(state, {
      type: "commit",
      document: { ...initial, board: { ...initial.board, title: `Edit ${i}` } },
    });
  assert.equal(state.past.length, 40);
  state = reduceHistory(state, { type: "undo" });
  assert.equal(state.future.length, 1);
  state = reduceHistory(state, { type: "commit", document: initial });
  assert.equal(state.future.length, 0);
});
test("history resets do not apply old maps to a different photo", () => {
  const initial = { board: board(), imageDataUrl: "old" };
  let state: HistoryState = {
    past: [initial],
    present: initial,
    future: [initial],
    revision: 0,
  };
  state = reduceHistory(state, {
    type: "reset",
    document: { board: EMPTY_BOARD, imageDataUrl: "new" },
  });
  state = reduceHistory(state, { type: "undo" });
  assert.equal(state.present.imageDataUrl, "new");
  assert.equal(state.past.length, 0);
});
test("nominal voltage remains explicitly nominal; nonfinite live values are rejected", () => {
  const pin = board().components[0]!.pinSpecs[0]!;
  assert.equal(voltageFor(pin).source, "NOMINAL");
  assert.equal(
    voltageFor(pin, { readVoltage: () => ({ value: NaN, source: "MNA" }) })
      .source,
    "NOMINAL",
  );
  assert.equal(
    voltageFor(pin, { readVoltage: () => ({ value: 12.4, source: "MNA" }) })
      .value,
    12.4,
  );
});
const deps = () => ({
  crop: async (_image: string, _crop: object) => ({
    imageBase64: "jpeg",
    mimeType: "image/jpeg",
    localCv: "cv",
  }),
  analyze: async (_input: object): Promise<{ detectionMethod: string }> => ({
    detectionMethod: "AI_ANALYZED",
  }),
  fuse: (_ai: { detectionMethod: string } | null, _cv: string) => board(),
  merge: (
    _before: ReturnType<typeof board>,
    _crop: object,
    result: ReturnType<typeof board>,
  ) => ({ ...result, addedCount: 0 }),
  toLegacyBoard: (b: ReturnType<typeof board>) => b,
});
const context = (signal: AbortSignal) => ({
  imageBase64: "image",
  mimeType: "image/jpeg" as const,
  documentName: "test.jpg",
  signal,
  onProgress: (_message: string) => {},
});
test("hybrid adapter falls back when AI fails", async () => {
  let seen: unknown = "not-called";
  const adapter = createHybridVisionAdapter({
    ...deps(),
    analyze: async () => {
      throw new Error("offline");
    },
    fuse: (ai, _cv) => {
      seen = ai;
      return board();
    },
  });
  const result = await adapter.analyzeImage!(
    context(new AbortController().signal),
  );
  assert.equal(seen, null);
  assert.equal(result.components.length, 6);
});
test("hybrid adapter stops before work for an already-aborted request", async () => {
  const controller = new AbortController();
  controller.abort();
  const adapter = createHybridVisionAdapter(deps());
  await assert.rejects(adapter.analyzeImage!(context(controller.signal)), {
    name: "AbortError",
  });
});
test("hybrid adapter rejects late AI results after cancellation", async () => {
  const controller = new AbortController();
  const adapter = createHybridVisionAdapter({
    ...deps(),
    analyze: async () => {
      controller.abort();
      return { detectionMethod: "AI_ANALYZED" };
    },
  });
  await assert.rejects(adapter.analyzeImage!(context(controller.signal)), {
    name: "AbortError",
  });
});
test("region adapter preserves board metadata while merging map results", async () => {
  const b = board();
  b.title = "Keep board title";
  const adapter = createHybridVisionAdapter(deps());
  const result = await adapter.analyzeRegion!({
    ...context(new AbortController().signal),
    board: b,
    crop: { xmin: 100, ymin: 100, xmax: 400, ymax: 400 },
  });
  assert.equal(result.title, "Keep board title");
  assert.equal(result.components.length, 6);
});
