import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

test.beforeEach(async ({ page }) => {
  await page.goto("/");
});
test("loads without runtime errors and renders accessible inspector", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await expect(
    page.getByRole("heading", { name: "PCB Vision / Inspection Lab" }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "J1 CONNECTOR" }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Undo", exact: true }),
  ).toBeDisabled();
  expect(errors).toEqual([]);
});
test("edits are undoable and redoable with keyboard shortcuts", async ({
  page,
}) => {
  const marking = page.getByLabel("Marking", { exact: true });
  await marking.fill("UPDATED CONNECTOR");
  await marking.press("Enter");
  await expect(marking).toHaveValue("UPDATED CONNECTOR");
  await page.getByRole("button", { name: "Undo", exact: true }).click();
  await expect(marking).toHaveValue("BENCH INPUT");
  await page.getByRole("button", { name: "Redo", exact: true }).click();
  await expect(marking).toHaveValue("UPDATED CONNECTOR");
});
test("Escape discards an uncommitted field draft", async ({ page }) => {
  const marking = page.getByLabel("Marking", { exact: true });
  await marking.fill("DO NOT COMMIT");
  await marking.press("Escape");
  await expect(marking).toHaveValue("BENCH INPUT");
  await expect(
    page.getByRole("button", { name: "Undo", exact: true }),
  ).toBeDisabled();
});
test("adding, searching, deleting and undoing keeps the registry consistent", async ({
  page,
}) => {
  await page.getByRole("button", { name: "Add part", exact: true }).click();
  await page.getByRole("button", { name: "TEST POINT", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "TP2 TEST POINT" }),
  ).toBeVisible();
  const search = page.getByRole("textbox", { name: "Search components" });
  await search.fill("TP2");
  await expect(page.locator(".pcb-registry-list button")).toHaveCount(1);
  await page.getByRole("button", { name: "Remove TP2", exact: true }).click();
  await expect(page.locator(".pcb-registry-list button")).toHaveCount(0);
  await page.getByRole("button", { name: "Undo", exact: true }).click();
  await expect(page.locator(".pcb-registry-list button")).toHaveCount(1);
});
test("dragging groups frames into one history entry and Escape rolls back", async ({
  page,
}) => {
  await page.getByRole("button", { name: "Fit board", exact: true }).click();
  const target = page.getByRole("button", {
    name: "Select U1, GENERIC 5V LDO",
    exact: true,
  });
  const box = await target.boundingBox();
  expect(box).not.toBeNull();
  const x = box!.x + box!.width / 2,
    y = box!.y + box!.height / 2;
  const before = await target.getAttribute("x");
  await page.mouse.move(x, y);
  await page.mouse.down();
  await page.mouse.move(x + 50, y + 30, { steps: 10 });
  await page.mouse.up();
  expect(await target.getAttribute("x")).not.toBe(before);
  await page.getByRole("button", { name: "Undo", exact: true }).click();
  await expect(target).toHaveAttribute("x", before!);
  await expect(
    page.getByRole("button", { name: "Undo", exact: true }),
  ).toBeDisabled();
  const restored = await target.boundingBox();
  await page.mouse.move(
    restored!.x + restored!.width / 2,
    restored!.y + restored!.height / 2,
  );
  await page.mouse.down();
  await page.mouse.move(x + 70, y + 50);
  await page.keyboard.press("Escape");
  await page.mouse.up();
  await expect(target).toHaveAttribute("x", before!);
});
test("pin-net reassignment updates both sides of the registry", async ({
  page,
}) => {
  const field = page.getByLabel("Net ID", { exact: true }).first();
  await field.fill("NET_CUSTOM");
  await field.press("Enter");
  await page.getByRole("button", { name: "NETS", exact: true }).click();
  const old = page.locator(".pcb-net-card").filter({
    has: page.getByRole("button", { name: "NET_VBAT", exact: true }),
  });
  const added = page.locator(".pcb-net-card").filter({
    has: page.getByRole("button", { name: "NET_CUSTOM", exact: true }),
  });
  await expect(old.locator("p")).not.toContainText("J1");
  await expect(added.locator("p")).toHaveText("J1");
});
test("nominal probes never display a fabricated live differential reading", async ({
  page,
}) => {
  await page
    .getByRole("button", { name: "Probe J1 pin 1", exact: true })
    .click();
  await page.getByRole("button", { name: "PART", exact: true }).click();
  await page
    .getByRole("button", { name: "Probe J1 pin 2", exact: true })
    .click();
  await expect(page.locator(".pcb-meter small")).toHaveText(
    "NO COMPARABLE LIVE / MEASURED DATA",
  );
  await expect(page.locator(".pcb-meter strong")).toHaveText("—");
});
test("keyboard can select a pin and move a component without pointer input", async ({
  page,
}) => {
  const part = page.getByRole("button", {
    name: "Select U1, GENERIC 5V LDO",
    exact: true,
  });
  await part.focus();
  await part.press("Enter");
  await expect(
    page.getByRole("heading", { name: "U1 VOLTAGE REGULATOR" }),
  ).toBeVisible();
  const old = Number(await part.getAttribute("x"));
  await part.press("ArrowRight");
  await expect(part).toHaveAttribute("x", String(old + 1));
});
test("export creates a versioned portable project", async ({ page }) => {
  const downloadPromise = page.waitForEvent("download");
  await page.getByRole("button", { name: "Export", exact: true }).click();
  const download = await downloadPromise;
  expect(download.suggestedFilename()).toMatch(/^pcb-.*\.json$/);
  const stream = await download.createReadStream();
  if (!stream) throw new Error("Missing download stream");
  const chunks: Buffer[] = [];
  for await (const chunk of stream) chunks.push(Buffer.from(chunk));
  const exported = JSON.parse(Buffer.concat(chunks).toString("utf8"));
  expect(exported.schemaVersion).toBe(1);
  expect(exported.board.components).toHaveLength(6);
});
test("rejects malformed JSON without replacing the current document", async ({
  page,
}) => {
  await page.locator('input[accept="application/json,.json"]').setInputFiles({
    name: "bad.json",
    mimeType: "application/json",
    buffer: Buffer.from('{"unrelated":true}'),
  });
  await expect(page.locator(".pcb-status")).toContainText("Error:");
  await expect(
    page.getByRole("heading", { name: "J1 CONNECTOR" }),
  ).toBeVisible();
});
test("late analysis results cannot overwrite the board after cancellation", async ({
  page,
}) => {
  await page.goto("/?slow=1");
  const pngBase64 = await page.evaluate(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 20;
    canvas.height = 10;
    return canvas.toDataURL("image/png").split(",")[1]!;
  });
  const png = Buffer.from(pngBase64, "base64");
  await page
    .locator('input[accept="image/jpeg,image/png,image/webp"]')
    .setInputFiles({ name: "tiny.png", mimeType: "image/png", buffer: png });
  await expect(
    page.getByRole("button", { name: "Cancel", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Cancel", exact: true }).click();
  await page.waitForTimeout(1000);
  await expect(page.locator(".pcb-project-name")).toContainText("tiny");
  await expect(page.locator(".pcb-project-name")).not.toContainText(
    "LATE RESULT",
  );
});
test("mobile inspector is usable without horizontal page overflow", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole("button", { name: "Inspector", exact: true }).click();
  await expect(page.getByLabel("Marking", { exact: true })).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
});
test("automated accessibility check has no serious or critical violations", async ({
  page,
}) => {
  const result = await new AxeBuilder({ page })
    .include(".pcb-workspace")
    .analyze();
  const violations = result.violations.filter((v) =>
    ["critical", "serious"].includes(v.impact ?? ""),
  );
  expect(
    violations.map((v) => ({
      id: v.id,
      targets: v.nodes.map((n) => n.target),
    })),
  ).toEqual([]);
});
test("captures desktop reference preview", async ({ page }) => {
  await page.getByRole("button", { name: "Fit board", exact: true }).click();
  await page
    .getByRole("button", { name: "Select U1, GENERIC 5V LDO", exact: true })
    .focus();
  await page.keyboard.press("Enter");
  await page.screenshot({
    path: "dist/pcb-workspace-preview.png",
    fullPage: true,
  });
});
