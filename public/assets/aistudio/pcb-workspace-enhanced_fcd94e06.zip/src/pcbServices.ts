import type { Board, Box, Finding, Pin, Part } from "./pcbModel";
import type { BoardDocument } from "./useBoardHistory";

export interface ScanContext {
  imageBase64: string;
  mimeType: "image/jpeg";
  documentName: string;
  signal: AbortSignal;
  onProgress(message: string): void;
}
export interface SavedScan {
  id: string;
  title: string;
  document: BoardDocument;
}
/** Adapter boundary: normalize and validate remote results before returning them.
 * Put AI credentials on your server. Enforce auth, ownership, payload limits and rate limits there.
 */
export interface PcbServices {
  analyzeImage?(context: ScanContext): Promise<Board>;
  /** Must return a merged full-board map, not crop-local coordinates. */
  analyzeRegion?(
    context: ScanContext & { crop: Box; board: Board },
  ): Promise<Board>;
  save?(
    document: BoardDocument,
    context: { signal: AbortSignal },
  ): Promise<void>;
  subscribeSaved?(
    onData: (scans: SavedScan[]) => void,
    onError: (error: Error) => void,
  ): () => void;
  deleteSaved?(id: string, context: { signal: AbortSignal }): Promise<void>;
}
export interface VoltageReading {
  value: number;
  source: "MNA" | "MEASURED" | "NOMINAL";
  nodeId?: string;
}
export interface ThermalReading {
  tempC: number;
  powerDissipationMw: number;
  source: "SIMULATED" | "MEASURED";
  note?: string;
}
export interface Diagnostics {
  readVoltage?(netId: string, nominalVoltage: number): VoltageReading;
  thermal?: Record<string, ThermalReading>;
  findings?: Finding[];
  /** Only expose true when the bench state confirms the board is energized. */
  powerEnabled?: boolean;
}
export interface PcbWorkspaceProps {
  initialBoard?: Board;
  initialImageDataUrl?: string | null;
  presets?: { board: Board; imageDataUrl?: string }[];
  services?: PcbServices;
  diagnostics?: Diagnostics;
  onOpenGroundedSearch?: (query?: string, dtc?: string, ecu?: string) => void;
  onOpenOfflineBot?: (prompt?: string) => void;
  onOpenCloudModal?: () => void;
  onChange?: (document: BoardDocument) => void;
}
export function voltageFor(
  pin: Pin,
  diagnostics?: Diagnostics,
): VoltageReading {
  const result = diagnostics?.readVoltage?.(
    pin.connectedNetId,
    pin.nominalVoltage,
  );
  return result && Number.isFinite(result.value)
    ? result
    : { value: pin.nominalVoltage, source: "NOMINAL" };
}
export function partSearchText(part: Part): string {
  return `${part.refDes} ${part.category} ${part.marking} ${part.decodedValue}`.toLowerCase();
}
export async function prepareImage(
  file: File,
): Promise<{ imageDataUrl: string; aspect: number }> {
  if (!["image/jpeg", "image/png", "image/webp"].includes(file.type))
    throw new Error("Use a JPEG, PNG, or WebP image.");
  if (file.size > 12 * 1024 * 1024)
    throw new Error("Image exceeds the 12 MB limit.");
  const bitmap = await createImageBitmap(file, {
    imageOrientation: "from-image",
  });
  try {
    if (
      bitmap.width * bitmap.height > 60_000_000 ||
      bitmap.width < 1 ||
      bitmap.height < 1
    )
      throw new Error(
        "Image dimensions exceed the supported 60-megapixel limit.",
      );
    const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Canvas 2D is unavailable.");
    context.fillStyle = "#ffffff";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    return {
      imageDataUrl: canvas.toDataURL("image/jpeg", 0.88),
      aspect: bitmap.width / bitmap.height,
    };
  } finally {
    bitmap.close();
  }
}
