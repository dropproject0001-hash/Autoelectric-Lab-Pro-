import React, {
  useCallback,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  Upload,
  Download,
  Undo2,
  Redo2,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Hand,
  MousePointer2,
  Crosshair,
  Crop,
  Route,
  Flame,
  Layers,
  Search,
  Plus,
  Trash2,
  CheckCircle2,
  X,
  Save,
  FolderOpen,
  Activity,
  AlertTriangle,
  FileJson,
  ExternalLink,
  Bot,
} from "lucide-react";
import {
  addPart,
  auditBoard,
  branches,
  clamp,
  connectedPartPath,
  decodeBoard,
  EMPTY_BOARD,
  importBoard,
  movePart,
  normalizeBox,
  normalizeNetName,
  Part,
  Pin,
  Point,
  Box,
  ProbeTarget,
  reconcileNets,
  removePart,
  resolveProbe,
  routeNet,
  serializeBoard,
  Template,
  UNASSIGNED,
  updatePin,
  withBranches,
  pinPoint,
} from "./pcbModel";
import { BoardDocument, useBoardHistory } from "./useBoardHistory";
import {
  partSearchText,
  PcbWorkspaceProps,
  prepareImage,
  SavedScan,
  ScanContext,
  voltageFor,
} from "./pcbServices";
import "./pcb-workspace.css";

type Mode = "SELECT" | "PAN" | "PROBE" | "CROP" | "TRACE" | "PATH";
type Tab = "PART" | "NETS" | "PROBE" | "AUDIT" | "THERMAL";
type Drag =
  | {
      type: "PART";
      ref: string;
      resize: boolean;
      start: Point;
      baseline: BoardDocument;
      rect: DOMRect;
      pointerId: number;
    }
  | {
      type: "TRACE";
      net: string;
      branch: number;
      index: number;
      baseline: BoardDocument;
      rect: DOMRect;
      pointerId: number;
    }
  | { type: "CROP"; start: Point; rect: DOMRect; pointerId: number }
  | { type: "PAN"; start: Point; scroll: Point; pointerId: number };
const MODES: { id: Mode; label: string; icon: React.ReactNode }[] = [
  { id: "SELECT", label: "Edit boxes", icon: <MousePointer2 size={15} /> },
  { id: "PAN", label: "Pan", icon: <Hand size={15} /> },
  { id: "PROBE", label: "Probe A/B", icon: <Crosshair size={15} /> },
  { id: "TRACE", label: "Edit traces", icon: <Route size={15} /> },
  { id: "PATH", label: "Connectivity", icon: <Activity size={15} /> },
  { id: "CROP", label: "Macro crop", icon: <Crop size={15} /> },
];
const TEMPLATES: Template[] = [
  "TEST_POINT",
  "RESISTOR",
  "CAPACITOR",
  "DIODE",
  "MOSFET_DRIVER",
  "VOLTAGE_REGULATOR",
];
const colorFor = (name: string): string =>
  /GND|GROUND/i.test(name)
    ? "#4ade80"
    : /VBAT|KL30/i.test(name)
      ? "#fb7185"
      : /5V|REG/i.test(name)
        ? "#22d3ee"
        : /CANH|HIGH/i.test(name)
          ? "#fb923c"
          : /CANL|LOW/i.test(name)
            ? "#c084fc"
            : "#fbbf24";
const toNorm = (x: number, y: number, rect: DOMRect): Point => ({
  x: clamp(((x - rect.left) / Math.max(1, rect.width)) * 1000),
  y: clamp(((y - rect.top) / Math.max(1, rect.height)) * 1000),
});
const errorText = (e: unknown): string =>
  e instanceof Error ? e.message : "Unexpected operation failure";
const isEditable = (target: EventTarget | null): boolean =>
  target instanceof HTMLElement &&
  Boolean(target.closest('input,textarea,select,[contenteditable="true"]'));
const safeImage = (value: string | null | undefined): string | null =>
  value &&
  /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=\r\n]+$/.test(value) &&
  value.length < 25_000_000
    ? value
    : null;
function downloadJson(document: BoardDocument) {
  // JSON includes a compressed image for portable, correctly aligned projects.
  const payload = {
    ...JSON.parse(serializeBoard(document.board)),
    imageDataUrl: document.imageDataUrl,
  };
  const url = URL.createObjectURL(
    new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }),
  );
  const anchor = window.document.createElement("a");
  anchor.href = url;
  anchor.download = `pcb-${document.board.title.replace(/[^a-z0-9_-]+/gi, "-").slice(0, 80) || "map"}.json`;
  window.document.body.append(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function Field({
  label,
  value,
  onCommit,
  numeric = false,
}: {
  label: string;
  value: string | number;
  onCommit(value: string): void;
  numeric?: boolean;
}) {
  const [draft, setDraft] = useState(String(value));
  const id = useId();
  useEffect(() => setDraft(String(value)), [value]);
  return (
    <label className="pcb-field" htmlFor={id}>
      <span>{label}</span>
      <input
        id={id}
        type={numeric ? "number" : "text"}
        step={numeric ? "any" : undefined}
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={(e) => {
          const next = e.currentTarget.value;
          if (next !== String(value)) onCommit(next);
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter") e.currentTarget.blur();
          if (e.key === "Escape") {
            e.stopPropagation();
            e.currentTarget.value = String(value);
            setDraft(String(value));
            e.currentTarget.blur();
          }
        }}
      />
    </label>
  );
}

/** Pure UI plus dependency-injected analysis/storage/diagnostic adapters.
 * React 18+. No global DOM IDs, AI keys, fabricated live readings or hidden network calls.
 */
export function PcbWorkspace({
  initialBoard = EMPTY_BOARD,
  initialImageDataUrl,
  presets = [],
  services,
  diagnostics,
  onOpenGroundedSearch,
  onOpenOfflineBot,
  onOpenCloudModal,
  onChange,
}: PcbWorkspaceProps) {
  const [initial] = useState<BoardDocument>(() => ({
    board: decodeBoard(initialBoard),
    imageDataUrl: safeImage(initialImageDataUrl),
  }));
  const { state, stateRef, dispatch, commit } = useBoardHistory(initial);
  const { board, imageDataUrl } = state.present;
  const [mode, setMode] = useState<Mode>("SELECT");
  const [tab, setTab] = useState<Tab>("PART");
  const [selection, setSelection] = useState<string | null>(
    board.components[0]?.refDes ?? null,
  );
  const [activeNet, setActiveNet] = useState<string | null>(null);
  const [hoverNet, setHoverNet] = useState<string | null>(null);
  const [hoverPin, setHoverPin] = useState<ProbeTarget | null>(null);
  const [pathPair, setPathPair] = useState<[string | null, string | null]>([
    null,
    null,
  ]);
  const [probeTargets, setProbeTargets] = useState<
    [ProbeTarget | null, ProbeTarget | null]
  >([null, null]);
  const [nextProbe, setNextProbe] = useState<0 | 1>(0);
  const [zoom, setZoom] = useState(1);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("ALL");
  const [layers, setLayers] = useState({
    photo: true,
    parts: true,
    traces: true,
    pins: true,
    voltages: false,
    hotspots: true,
    thermal: false,
  });
  const [opticalFilter, setOpticalFilter] = useState("normal");
  const [crop, setCrop] = useState<Box | null>(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState(
    "Ready. Upload an image, load a preset, or add a component.",
  );
  const [saved, setSaved] = useState<SavedScan[]>([]);
  const [savedOpen, setSavedOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);
  const [mobilePanel, setMobilePanel] = useState<"BOARD" | "INSPECTOR">(
    "BOARD",
  );
  const viewportRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLDivElement>(null);
  const rootRef = useRef<HTMLElement>(null);
  const dragRef = useRef<Drag | null>(null);
  const frameRef = useRef<number | null>(null);
  const pendingMoveRef = useRef<{ x: number; y: number } | null>(null);
  const operationRef = useRef<{
    id: number;
    controller: AbortController;
  } | null>(null);
  const operationSequence = useRef(0);
  const mountedRef = useRef(false);
  const cropRef = useRef<Box | null>(null);
  const svgId = useId().replace(/:/g, "");
  const effectiveNet = hoverNet ?? activeNet;
  const selected = useMemo(
    () => board.components.find((p) => p.refDes === selection),
    [board.components, selection],
  );
  const visibleParts = useMemo(
    () =>
      board.components.filter(
        (p) =>
          partSearchText(p).includes(query.toLowerCase()) &&
          (filter === "ALL" || p.verificationStatus === filter),
      ),
    [board.components, query, filter],
  );
  const findings = useMemo(
    () => [...auditBoard(board), ...(diagnostics?.findings ?? [])],
    [board, diagnostics?.findings],
  );
  const path = useMemo(
    () => connectedPartPath(board, ...pathPair),
    [board, pathPair],
  );
  const probeA = resolveProbe(board, probeTargets[0]);
  const probeB = resolveProbe(board, probeTargets[1]);
  const hover = resolveProbe(board, hoverPin);
  const vA = probeA ? voltageFor(probeA.pin, diagnostics) : null;
  const vB = probeB ? voltageFor(probeB.pin, diagnostics) : null;
  const differentialValid =
    vA && vB && vA.source !== "NOMINAL" && vA.source === vB.source;
  const [thermalMin, thermalMax] = [25, 125];

  useEffect(() => {
    onChange?.(state.present);
  }, [state.present, onChange]);
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      operationRef.current?.controller.abort();
      if (frameRef.current !== null) cancelAnimationFrame(frameRef.current);
    };
  }, []);
  useEffect(() => {
    setSaved([]);
    if (!services?.subscribeSaved) return;
    return services.subscribeSaved(
      (scans) => {
        if (mountedRef.current) setSaved(scans);
      },
      (e) => {
        if (mountedRef.current)
          setStatus(`Saved library unavailable: ${e.message}`);
      },
    );
  }, [services]);
  const cancelOperation = useCallback(() => {
    operationRef.current?.controller.abort();
    operationRef.current = null;
    setBusy(false);
    setStatus("Operation cancelled.");
  }, []);
  const perform = useCallback(
    async (
      label: string,
      work: (
        signal: AbortSignal,
        report: (message: string) => void,
      ) => Promise<void>,
    ) => {
      operationRef.current?.controller.abort();
      const op = {
        id: ++operationSequence.current,
        controller: new AbortController(),
      };
      operationRef.current = op;
      const current = () =>
        mountedRef.current &&
        operationRef.current?.id === op.id &&
        !op.controller.signal.aborted;
      setBusy(true);
      setStatus(label);
      try {
        await work(op.controller.signal, (message) => {
          if (current()) setStatus(message);
        });
      } catch (e) {
        if (current()) setStatus(`Error: ${errorText(e)}`);
      } finally {
        if (current()) {
          operationRef.current = null;
          setBusy(false);
        }
      }
    },
    [],
  );
  const resetSelection = useCallback(() => {
    setSelection(null);
    setActiveNet(null);
    setHoverPin(null);
    setHoverNet(null);
    setProbeTargets([null, null]);
    setNextProbe(0);
    setPathPair([null, null]);
    setCrop(null);
    cropRef.current = null;
    setMode("SELECT");
    setZoom(1);
  }, []);
  const loadDocument = useCallback(
    (document: BoardDocument) => {
      cancelOperation();
      dispatch({
        type: "reset",
        document: {
          board: decodeBoard(document.board),
          imageDataUrl: safeImage(document.imageDataUrl),
        },
      });
      resetSelection();
      setStatus(`Loaded ${document.board.title}`);
    },
    [cancelOperation, dispatch, resetSelection],
  );
  const fit = useCallback(() => {
    const viewport = viewportRef.current;
    if (!viewport) return;
    setZoom(
      clamp(
        Math.min(
          (viewport.clientWidth - 40) / 960,
          (viewport.clientHeight - 40) / (960 / board.aspect),
        ),
        0.1,
        4,
      ),
    );
    viewport.scrollTo({ top: 0, left: 0 });
  }, [board.aspect]);
  const upload = async (file: File) => {
    await perform("Preparing image…", async (signal, report) => {
      const prepared = await prepareImage(file);
      if (signal.aborted || !mountedRef.current) return;
      const base = {
        ...EMPTY_BOARD,
        id: crypto.randomUUID(),
        title: file.name.replace(/\.[^.]+$/, ""),
        aspect: prepared.aspect,
      };
      dispatch({
        type: "reset",
        document: { board: base, imageDataUrl: prepared.imageDataUrl },
      });
      resetSelection();
      if (!services?.analyzeImage) {
        report(
          "Image loaded. Analysis adapter is not configured; use manual mapping.",
        );
        return;
      }
      const result = await services.analyzeImage({
        imageBase64: prepared.imageDataUrl.split(",")[1]!,
        mimeType: "image/jpeg",
        documentName: file.name,
        signal,
        onProgress: report,
      });
      if (signal.aborted || !mountedRef.current) return;
      const next = decodeBoard(result);
      dispatch({
        type: "commit",
        document: {
          board: { ...next, aspect: prepared.aspect },
          imageDataUrl: prepared.imageDataUrl,
        },
      });
      setSelection(next.components[0]?.refDes ?? null);
      report(
        `Mapped ${next.components.length} components and ${next.nets.length} nets. Verify inferred connections before bench use.`,
      );
    });
  };
  const scanRegion = useCallback(
    async (box: Box) => {
      const snapshot = stateRef.current.present;
      if (!snapshot.imageDataUrl || !services?.analyzeRegion) {
        setStatus(
          "Macro crop requires an image and a configured region-analysis adapter.",
        );
        return;
      }
      await perform("Analyzing selected region…", async (signal, report) => {
        const context: ScanContext = {
          imageBase64: snapshot.imageDataUrl!.split(",")[1]!,
          mimeType: "image/jpeg",
          documentName: `${snapshot.board.title}_crop.jpg`,
          signal,
          onProgress: report,
        };
        const result = await services.analyzeRegion!({
          ...context,
          crop: box,
          board: snapshot.board,
        });
        if (signal.aborted || !mountedRef.current) return;
        dispatch({
          type: "commit",
          document: {
            ...snapshot,
            board: { ...decodeBoard(result), aspect: snapshot.board.aspect },
          },
        });
        report("Region merged. Review new components and connectivity.");
        setCrop(null);
        setMode("SELECT");
      });
    },
    [dispatch, perform, services, stateRef],
  );
  const placeProbe = (target: ProbeTarget) => {
    setProbeTargets((previous) =>
      nextProbe === 0 ? [target, previous[1]] : [previous[0], target],
    );
    setNextProbe(nextProbe === 0 ? 1 : 0);
    setTab("PROBE");
  };
  const selectPart = (part: Part, shift = false) => {
    setSelection(part.refDes);
    setTab("PART");
    if (mode === "PATH" || shift)
      setPathPair(([a, b]) =>
        !a || b
          ? [part.refDes, null]
          : a === part.refDes
            ? [a, null]
            : [a, part.refDes],
      );
  };
  const editPart = (ref: string, patch: Partial<Part>) =>
    commit((b) => ({
      ...b,
      components: b.components.map((p) =>
        p.refDes === ref
          ? {
              ...p,
              ...patch,
              refDes: p.refDes,
              verificationStatus: "UNVERIFIED",
            }
          : p,
      ),
    }));
  const add = (template: Template) => {
    const added = addPart(stateRef.current.present.board, template);
    commit(() => added.board);
    setSelection(added.ref);
    setTab("PART");
    setAddOpen(false);
  };
  const clearDrag = useCallback(() => {
    if (frameRef.current !== null) cancelAnimationFrame(frameRef.current);
    frameRef.current = null;
    pendingMoveRef.current = null;
  }, []);
  const applyMove = useCallback(
    (client: Point) => {
      const drag = dragRef.current;
      if (!drag) return;
      if (drag.type === "PAN") {
        viewportRef.current?.scrollTo({
          left: drag.scroll.x - (client.x - drag.start.x),
          top: drag.scroll.y - (client.y - drag.start.y),
        });
        return;
      }
      const point = toNorm(client.x, client.y, drag.rect);
      if (drag.type === "CROP") {
        const box = normalizeBox({
          xmin: drag.start.x,
          ymin: drag.start.y,
          xmax: point.x,
          ymax: point.y,
        });
        cropRef.current = box;
        setCrop(box);
        return;
      }
      if (drag.type === "TRACE") {
        const next = {
          ...drag.baseline.board,
          nets: drag.baseline.board.nets.map((net) =>
            net.name !== drag.net
              ? net
              : withBranches(
                  net,
                  branches(net).map((branch, bi) =>
                    bi !== drag.branch
                      ? branch
                      : branch.map((p, pi) => (pi === drag.index ? point : p)),
                  ),
                ),
          ),
        };
        dispatch({
          type: "preview",
          document: { ...drag.baseline, board: next },
        });
        return;
      }
      const part = drag.baseline.board.components.find(
        (p) => p.refDes === drag.ref,
      );
      if (!part) return;
      const dx = point.x - drag.start.x,
        dy = point.y - drag.start.y;
      const orig = part.bbox;
      if (Math.abs(dx) < 0.1 && Math.abs(dy) < 0.1) return;
      const width = orig.xmax - orig.xmin,
        height = orig.ymax - orig.ymin;
      const x = clamp(orig.xmin + dx, 0, 1000 - width),
        y = clamp(orig.ymin + dy, 0, 1000 - height);
      const bbox = drag.resize
        ? {
            ...orig,
            xmax: clamp(orig.xmax + dx, Math.min(1000, orig.xmin + 10)),
            ymax: clamp(orig.ymax + dy, Math.min(1000, orig.ymin + 10)),
          }
        : { xmin: x, ymin: y, xmax: x + width, ymax: y + height };
      const next = movePart(drag.baseline.board, drag.ref, bbox);
      dispatch({
        type: "preview",
        document: { ...drag.baseline, board: next },
      });
    },
    [dispatch],
  );
  const finishDrag = useCallback(
    (cancel: boolean, point?: Point) => {
      const drag = dragRef.current;
      if (!drag) return;
      clearDrag();
      if (!cancel && point) applyMove(point);
      dragRef.current = null;
      if (drag.type === "PART" || drag.type === "TRACE") {
        if (cancel) dispatch({ type: "preview", document: drag.baseline });
        else dispatch({ type: "finish", baseline: drag.baseline });
      } else if (drag.type === "CROP") {
        const box = cropRef.current;
        cropRef.current = null;
        if (cancel) setCrop(null);
        else if (box && box.xmax - box.xmin >= 20 && box.ymax - box.ymin >= 20)
          void scanRegion(box);
        else {
          setCrop(null);
          setStatus("Crop is too small. Draw a larger region.");
        }
      }
    },
    [applyMove, clearDrag, dispatch, scanRegion],
  );
  const capture = (event: React.PointerEvent<Element>, drag: Drag) => {
    event.preventDefault();
    event.stopPropagation();
    dragRef.current = drag;
    canvasRef.current?.setPointerCapture(event.pointerId);
  };
  const deleteSelected = useCallback(() => {
    if (!selection || busy || dragRef.current) return;
    commit((b) => removePart(b, selection));
    setSelection(null);
    setStatus("Component removed. Undo is available.");
  }, [busy, commit, selection]);
  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        if (dragRef.current) finishDrag(true);
        else if (busy) cancelOperation();
        setPendingDelete(null);
        return;
      }
      if (isEditable(event.target) || busy || dragRef.current) return;
      const command = event.ctrlKey || event.metaKey;
      if (command && event.key.toLowerCase() === "z") {
        event.preventDefault();
        dispatch({ type: event.shiftKey ? "redo" : "undo" });
      } else if (command && event.key.toLowerCase() === "y") {
        event.preventDefault();
        dispatch({ type: "redo" });
      } else if (event.key === "Delete") {
        event.preventDefault();
        deleteSelected();
      } else if (event.key.toLowerCase() === "f") {
        event.preventDefault();
        fit();
      } else if (event.key.toLowerCase() === "v") setMode("SELECT");
      else if (event.key.toLowerCase() === "h") setMode("PAN");
      else if (event.key.toLowerCase() === "p") setMode("PROBE");
    };
    root.addEventListener("keydown", onKey);
    return () => root.removeEventListener("keydown", onKey);
  }, [busy, cancelOperation, deleteSelected, dispatch, finishDrag, fit]);
  useEffect(() => {
    const viewport = viewportRef.current;
    if (!viewport) return;
    const onWheel = (event: WheelEvent) => {
      if (!event.ctrlKey && !event.metaKey) return;
      event.preventDefault();
      if (dragRef.current) return;
      const rect = viewport.getBoundingClientRect();
      const x = event.clientX - rect.left,
        y = event.clientY - rect.top;
      // Preserve the cursor's board-space point across zoom (padding is fixed).
      const oldWidth = Math.max(viewport.clientWidth, 960 * zoom + 40);
      const oldHeight = Math.max(
        viewport.clientHeight,
        (960 / board.aspect) * zoom + 40,
      );
      const oldOffsetX = (oldWidth - 960 * zoom) / 2,
        oldOffsetY = (oldHeight - (960 / board.aspect) * zoom) / 2;
      const next = clamp(zoom * Math.exp(-event.deltaY * 0.002), 0.1, 4);
      const ratio = next / zoom;
      const newWidth = Math.max(viewport.clientWidth, 960 * next + 40);
      const newHeight = Math.max(
        viewport.clientHeight,
        (960 / board.aspect) * next + 40,
      );
      const newOffsetX = (newWidth - 960 * next) / 2,
        newOffsetY = (newHeight - (960 / board.aspect) * next) / 2;
      const left =
        (viewport.scrollLeft + x - oldOffsetX) * ratio + newOffsetX - x;
      const top =
        (viewport.scrollTop + y - oldOffsetY) * ratio + newOffsetY - y;
      setZoom(next);
      requestAnimationFrame(() => viewport.scrollTo({ left, top }));
    };
    viewport.addEventListener("wheel", onWheel, { passive: false });
    return () => viewport.removeEventListener("wheel", onWheel);
  }, [board.aspect, zoom]);
  const changePin = (pin: Pin, patch: Partial<Pin>) => {
    if (selected)
      commit((b) => updatePin(b, selected.refDes, pin.pinNumber, patch));
  };
  const importJson = async (file: File) => {
    await perform("Importing project…", async (signal, report) => {
      if (file.size > 30 * 1024 * 1024)
        throw new Error("Project exceeds the 30 MB import limit.");
      const text = await file.text();
      const next = importBoard(text);
      const root: unknown = JSON.parse(text);
      const image =
        root && typeof root === "object" && "imageDataUrl" in root
          ? safeImage(
              typeof root.imageDataUrl === "string" ? root.imageDataUrl : null,
            )
          : null;
      if (signal.aborted || !mountedRef.current) return;
      dispatch({
        type: "reset",
        document: { board: next, imageDataUrl: image },
      });
      resetSelection();
      report("Project imported and validated.");
    });
  };
  const save = () => {
    if (!services?.save) {
      onOpenCloudModal?.();
      setStatus(
        "Cloud storage adapter is not configured. Export JSON to keep this project.",
      );
      return;
    }
    const snapshot = stateRef.current.present;
    void perform("Saving project…", async (signal, report) => {
      await services.save!(snapshot, { signal });
      report("Project saved.");
    });
  };
  const pinClick = (part: Part, pin: Pin, shift: boolean) => {
    const target = { compRefDes: part.refDes, pinNumber: pin.pinNumber };
    if (mode === "PROBE") placeProbe(target);
    else {
      selectPart(part, shift);
      setActiveNet(pin.connectedNetId);
    }
  };
  const thermalValues = Object.values(diagnostics?.thermal ?? {})
    .map((t) => t.tempC)
    .filter(Number.isFinite);
  const peak = thermalValues.length ? Math.max(...thermalValues) : null;

  return (
    <section
      ref={rootRef}
      className="pcb-workspace"
      aria-label="PCB inspection workspace"
      tabIndex={-1}
      onPointerDownCapture={() => {
        if (!rootRef.current?.contains(document.activeElement))
          rootRef.current?.focus({ preventScroll: true });
      }}
    >
      <header className="pcb-header">
        <div className="pcb-brand">
          <div className="pcb-brand-icon">
            <Layers size={22} />
          </div>
          <div>
            <div className="pcb-eyebrow">ENGINEERING WORKSPACE</div>
            <h1>
              PCB Vision <span>/ Inspection Lab</span>
            </h1>
          </div>
        </div>
        <div className="pcb-badges">
          <span className="pcb-badge">
            <i />
            {diagnostics?.powerEnabled === true
              ? "BENCH ENERGIZED"
              : diagnostics?.powerEnabled === false
                ? "BENCH OFF"
                : "BENCH STATE UNKNOWN"}
          </span>
          {peak !== null && (
            <span className="pcb-badge">
              <Flame size={13} /> Model / sensor peak {peak.toFixed(1)}°C
            </span>
          )}
        </div>
        <div className="pcb-header-actions">
          <button
            disabled={busy || !state.past.length}
            onClick={() => dispatch({ type: "undo" })}
            title="Undo (Ctrl/Cmd+Z)"
            aria-label="Undo"
          >
            <Undo2 size={16} />
          </button>
          <button
            disabled={busy || !state.future.length}
            onClick={() => dispatch({ type: "redo" })}
            title="Redo (Ctrl/Cmd+Shift+Z)"
            aria-label="Redo"
          >
            <Redo2 size={16} />
          </button>
          <button disabled={busy} onClick={save}>
            <Save size={15} />
            <span>Save</span>
          </button>
          <button disabled={busy} onClick={() => downloadJson(state.present)}>
            <Download size={15} />
            <span>Export</span>
          </button>
          <label
            className={`pcb-button pcb-primary ${busy ? "is-disabled" : ""}`}
          >
            <Upload size={15} />
            Upload PCB
            <input
              disabled={busy}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              onChange={(event) => {
                const file = event.currentTarget.files?.[0];
                event.currentTarget.value = "";
                if (file) void upload(file);
              }}
            />
          </label>
        </div>
      </header>
      <div className="pcb-project-bar">
        <div className="pcb-project-name">
          <strong>{board.title}</strong>
          <span>
            {board.boardType} · {board.components.length} parts ·{" "}
            {board.nets.length} nets
          </span>
        </div>
        <div className="pcb-project-actions">
          {presets.length > 0 && (
            <select
              aria-label="Load reference preset"
              value=""
              disabled={busy}
              onChange={(event) => {
                const preset = presets[Number(event.target.value)];
                if (preset)
                  loadDocument({
                    board: preset.board,
                    imageDataUrl: preset.imageDataUrl ?? null,
                  });
              }}
            >
              <option value="" disabled>
                Reference presets
              </option>
              {presets.map((preset, i) => (
                <option value={i} key={`${preset.board.id}-${i}`}>
                  {preset.board.title}
                </option>
              ))}
            </select>
          )}
          <label className={`pcb-button ${busy ? "is-disabled" : ""}`}>
            <FileJson size={14} />
            Import
            <input
              type="file"
              accept="application/json,.json"
              disabled={busy}
              onChange={(event) => {
                const file = event.currentTarget.files?.[0];
                event.currentTarget.value = "";
                if (file) void importJson(file);
              }}
            />
          </label>
          <button
            disabled={busy}
            onClick={() => setSavedOpen((value) => !value)}
            aria-expanded={savedOpen}
          >
            <FolderOpen size={14} />
            Saved ({saved.length})
          </button>
          <div className="pcb-add-wrapper">
            <button
              disabled={busy}
              onClick={() => setAddOpen((value) => !value)}
              aria-expanded={addOpen}
            >
              <Plus size={14} />
              Add part
            </button>
            {addOpen && (
              <div className="pcb-add-menu">
                {TEMPLATES.map((t) => (
                  <button key={t} onClick={() => add(t)}>
                    {t.replace(/_/g, " ")}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      {savedOpen && (
        <div className="pcb-saved">
          <strong>Saved projects</strong>
          {!saved.length && (
            <p>
              No saved maps available. Connect your authenticated storage
              adapter.
            </p>
          )}
          {saved.map((scan) => (
            <div key={scan.id}>
              <button
                disabled={busy}
                onClick={() => {
                  loadDocument(scan.document);
                  setSavedOpen(false);
                }}
              >
                {scan.title}
              </button>
              {services?.deleteSaved && (
                <button
                  disabled={busy}
                  onClick={() => setPendingDelete(scan.id)}
                  aria-label={`Delete saved project ${scan.title}`}
                >
                  <Trash2 size={14} />
                </button>
              )}
              {pendingDelete === scan.id && (
                <>
                  <span>Delete permanently from your library?</span>
                  <button
                    disabled={busy}
                    onClick={() =>
                      void perform(
                        "Deleting saved project…",
                        async (signal, report) => {
                          await services?.deleteSaved?.(scan.id, { signal });
                          if (!signal.aborted && mountedRef.current)
                            setPendingDelete(null);
                          report("Saved project deleted.");
                        },
                      )
                    }
                  >
                    Confirm delete
                  </button>
                  <button onClick={() => setPendingDelete(null)}>Cancel</button>
                </>
              )}
            </div>
          ))}
        </div>
      )}
      <div className="pcb-mobile-tabs">
        <button
          className={mobilePanel === "BOARD" ? "active" : ""}
          onClick={() => setMobilePanel("BOARD")}
        >
          Board canvas
        </button>
        <button
          className={mobilePanel === "INSPECTOR" ? "active" : ""}
          onClick={() => setMobilePanel("INSPECTOR")}
        >
          Inspector
        </button>
      </div>
      <div className="pcb-layout">
        <main
          className={`pcb-canvas-panel ${mobilePanel !== "BOARD" ? "pcb-mobile-hidden" : ""}`}
        >
          <div
            className="pcb-canvas-toolbar"
            role="toolbar"
            aria-label="Canvas interaction modes"
          >
            {MODES.map((tool) => (
              <button
                key={tool.id}
                disabled={
                  busy ||
                  (tool.id === "CROP" &&
                    (!imageDataUrl || !services?.analyzeRegion))
                }
                aria-pressed={mode === tool.id}
                onClick={() => setMode(tool.id)}
                className={mode === tool.id ? "active" : ""}
              >
                {tool.icon}
                {tool.label}
              </button>
            ))}
            <div className="pcb-spacer" />
            <button
              onClick={() => setZoom((z) => clamp(z / 1.2, 0.1, 4))}
              aria-label="Zoom out"
            >
              <ZoomOut size={15} />
            </button>
            <span className="pcb-zoom">{Math.round(zoom * 100)}%</span>
            <button
              onClick={() => setZoom((z) => clamp(z * 1.2, 0.1, 4))}
              aria-label="Zoom in"
            >
              <ZoomIn size={15} />
            </button>
            <button onClick={fit} title="Fit board (F)" aria-label="Fit board">
              <Maximize2 size={15} />
            </button>
          </div>
          <div className="pcb-layer-bar">
            {(Object.keys(layers) as (keyof typeof layers)[]).map((layer) => (
              <label key={layer}>
                <input
                  type="checkbox"
                  checked={layers[layer]}
                  onChange={(e) =>
                    setLayers((l) => ({ ...l, [layer]: e.target.checked }))
                  }
                />
                {layer}
              </label>
            ))}
            <select
              value={opticalFilter}
              aria-label="Display filter"
              onChange={(e) => setOpticalFilter(e.target.value)}
            >
              <option value="normal">Natural</option>
              <option value="contrast">Contrast</option>
              <option value="grayscale">Grayscale</option>
            </select>
          </div>
          {(mode === "PATH" || pathPair[0]) && (
            <div className="pcb-path-status">
              <Route size={14} />
              <span>
                {pathPair[0] ?? "Select part A"} →{" "}
                {pathPair[1] ?? "Select part B"}
                {pathPair[0] && pathPair[1]
                  ? path
                    ? ` · ${path.nets.join(" → ")} · schematic connectivity only`
                    : " · no mapped net connection"
                  : ""}
              </span>
              <button
                onClick={() => setPathPair([null, null])}
                aria-label="Clear connectivity selection"
              >
                <X size={13} />
              </button>
            </div>
          )}
          <div
            className="pcb-viewport"
            ref={viewportRef}
            aria-label="Scrollable board canvas"
          >
            <div
              className="pcb-stage"
              style={{
                width: `max(100%, ${960 * zoom + 40}px)`,
                height: `max(100%, ${(960 / board.aspect) * zoom + 40}px)`,
              }}
            >
              <div
                ref={canvasRef}
                className={`pcb-board pcb-mode-${mode.toLowerCase()}`}
                style={{
                  width: 960 * zoom,
                  height: (960 / board.aspect) * zoom,
                  aspectRatio: board.aspect,
                }}
                onPointerDown={(event) => {
                  if (busy || event.button !== 0) return;
                  const canvas = canvasRef.current,
                    viewport = viewportRef.current;
                  if (!canvas || !viewport) return;
                  if (mode === "PAN")
                    capture(event, {
                      type: "PAN",
                      start: { x: event.clientX, y: event.clientY },
                      scroll: { x: viewport.scrollLeft, y: viewport.scrollTop },
                      pointerId: event.pointerId,
                    });
                  else if (mode === "CROP") {
                    const rect = canvas.getBoundingClientRect();
                    const point = toNorm(event.clientX, event.clientY, rect);
                    cropRef.current = null;
                    setCrop(null);
                    capture(event, {
                      type: "CROP",
                      start: point,
                      rect,
                      pointerId: event.pointerId,
                    });
                  }
                }}
                onPointerMove={(event) => {
                  if (
                    !dragRef.current ||
                    event.pointerId !== dragRef.current.pointerId
                  )
                    return;
                  pendingMoveRef.current = {
                    x: event.clientX,
                    y: event.clientY,
                  };
                  if (frameRef.current === null)
                    frameRef.current = requestAnimationFrame(() => {
                      frameRef.current = null;
                      const p = pendingMoveRef.current;
                      if (p) applyMove(p);
                    });
                }}
                onPointerUp={(event) => {
                  if (event.pointerId === dragRef.current?.pointerId)
                    finishDrag(false, { x: event.clientX, y: event.clientY });
                }}
                onPointerCancel={() => finishDrag(true)}
                onLostPointerCapture={() => {
                  if (dragRef.current) finishDrag(true);
                }}
              >
                {imageDataUrl && layers.photo && (
                  <img
                    alt="Uploaded PCB reference"
                    draggable={false}
                    src={imageDataUrl}
                    className={`pcb-reference pcb-filter-${opticalFilter}`}
                  />
                )}
                <svg
                  className="pcb-overlay"
                  viewBox="0 0 1000 1000"
                  preserveAspectRatio="none"
                  aria-label="PCB annotation overlay"
                  role="group"
                >
                  <defs>
                    <pattern
                      id={`${svgId}-grid`}
                      width="25"
                      height="25"
                      patternUnits="userSpaceOnUse"
                    >
                      <path
                        d="M25 0H0V25"
                        fill="none"
                        stroke="#22483b"
                        strokeWidth="0.7"
                      />
                    </pattern>
                    {board.components.map((part) => (
                      <radialGradient
                        key={part.refDes}
                        id={`${svgId}-heat-${encodeURIComponent(part.refDes)}`}
                      >
                        <stop
                          offset="0%"
                          stopColor="#ff733e"
                          stopOpacity=".7"
                        />
                        <stop
                          offset="100%"
                          stopColor="#f43f5e"
                          stopOpacity="0"
                        />
                      </radialGradient>
                    ))}
                  </defs>
                  {(!imageDataUrl || !layers.photo) && (
                    <>
                      <rect
                        width="1000"
                        height="1000"
                        fill={`url(#${svgId}-grid)`}
                      />
                      <rect
                        x="18"
                        y="18"
                        width="964"
                        height="964"
                        rx="14"
                        fill="none"
                        stroke="#5b8f74"
                        strokeWidth="2"
                        strokeDasharray="9 5"
                      />
                      {[
                        [45, 45],
                        [955, 45],
                        [45, 955],
                        [955, 955],
                      ].map(([x, y], i) => (
                        <circle
                          key={i}
                          cx={x}
                          cy={y}
                          r="13"
                          fill="#07130f"
                          stroke="#c0aa65"
                          strokeWidth="6"
                        />
                      ))}
                    </>
                  )}
                  {layers.thermal &&
                    board.components.map((part) => {
                      const temp = diagnostics?.thermal?.[part.refDes]?.tempC;
                      if (temp === undefined || !Number.isFinite(temp))
                        return null;
                      return (
                        <ellipse
                          className="pcb-no-pointer"
                          key={part.refDes}
                          cx={(part.bbox.xmin + part.bbox.xmax) / 2}
                          cy={(part.bbox.ymin + part.bbox.ymax) / 2}
                          rx={Math.max(50, part.bbox.xmax - part.bbox.xmin)}
                          ry={Math.max(50, part.bbox.ymax - part.bbox.ymin)}
                          fill={`url(#${svgId}-heat-${encodeURIComponent(part.refDes)})`}
                          opacity={clamp(
                            (temp - thermalMin) / (thermalMax - thermalMin),
                            0,
                            1,
                          )}
                        />
                      );
                    })}
                  {layers.traces &&
                    board.nets.map((net) => (
                      <g
                        key={net.name}
                        className="pcb-net"
                        style={{
                          color: colorFor(net.name),
                          opacity:
                            effectiveNet && effectiveNet !== net.name
                              ? 0.25
                              : 1,
                        }}
                      >
                        {branches(net).map((branch, bi) => (
                          <g key={bi}>
                            <polyline
                              points={branch
                                .map((p) => `${p.x},${p.y}`)
                                .join(" ")}
                              stroke="transparent"
                              strokeWidth="20"
                              fill="none"
                              className={
                                mode === "PAN" || mode === "CROP"
                                  ? "pcb-no-pointer"
                                  : "pcb-hit"
                              }
                              onClick={() => {
                                if (!busy) {
                                  setActiveNet(net.name);
                                  setTab("NETS");
                                }
                              }}
                            />
                            <polyline
                              className="pcb-no-pointer"
                              points={branch
                                .map((p) => `${p.x},${p.y}`)
                                .join(" ")}
                              stroke="currentColor"
                              strokeWidth={effectiveNet === net.name ? 4 : 2.5}
                              fill="none"
                              strokeLinejoin="round"
                            />
                            {mode === "TRACE" &&
                              branch.map((p, pi) => (
                                <circle
                                  key={pi}
                                  cx={p.x}
                                  cy={p.y}
                                  r={6}
                                  fill="white"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  tabIndex={0}
                                  role="button"
                                  aria-label={`${net.name} branch ${bi + 1} vertex ${pi + 1}`}
                                  onKeyDown={(event) => {
                                    if (
                                      busy ||
                                      ![
                                        "ArrowLeft",
                                        "ArrowRight",
                                        "ArrowUp",
                                        "ArrowDown",
                                      ].includes(event.key)
                                    )
                                      return;
                                    event.preventDefault();
                                    const step = event.shiftKey ? 10 : 1;
                                    commit((b) => ({
                                      ...b,
                                      nets: b.nets.map((n) =>
                                        n.name !== net.name
                                          ? n
                                          : withBranches(
                                              n,
                                              branches(n).map((br, index) =>
                                                index !== bi
                                                  ? br
                                                  : br.map((pt, index) =>
                                                      index !== pi
                                                        ? pt
                                                        : {
                                                            x: clamp(
                                                              pt.x +
                                                                (event.key ===
                                                                "ArrowRight"
                                                                  ? step
                                                                  : event.key ===
                                                                      "ArrowLeft"
                                                                    ? -step
                                                                    : 0),
                                                            ),
                                                            y: clamp(
                                                              pt.y +
                                                                (event.key ===
                                                                "ArrowDown"
                                                                  ? step
                                                                  : event.key ===
                                                                      "ArrowUp"
                                                                    ? -step
                                                                    : 0),
                                                            ),
                                                          },
                                                    ),
                                              ),
                                            ),
                                      ),
                                    }));
                                  }}
                                  onPointerDown={(event) => {
                                    if (
                                      busy ||
                                      event.button !== 0 ||
                                      !canvasRef.current
                                    )
                                      return;
                                    capture(event, {
                                      type: "TRACE",
                                      net: net.name,
                                      branch: bi,
                                      index: pi,
                                      baseline: stateRef.current.present,
                                      rect: canvasRef.current.getBoundingClientRect(),
                                      pointerId: event.pointerId,
                                    });
                                  }}
                                />
                              ))}
                          </g>
                        ))}
                      </g>
                    ))}
                  {layers.hotspots &&
                    board.hotspots.map((h) => (
                      <rect
                        key={h.id}
                        x={h.bbox.xmin}
                        y={h.bbox.ymin}
                        width={h.bbox.xmax - h.bbox.xmin}
                        height={h.bbox.ymax - h.bbox.ymin}
                        className={`pcb-hotspot pcb-severity-${h.severity.toLowerCase()}`}
                        onClick={() => {
                          setTab("AUDIT");
                          setSelection(h.suspectComponentRef ?? null);
                        }}
                      >
                        <title>
                          {h.severity}: {h.label}
                        </title>
                      </rect>
                    ))}
                  {layers.parts &&
                    board.components.map((part) => (
                      <g
                        key={part.refDes}
                        className={`pcb-part ${selection === part.refDes ? "is-selected" : ""} ${pathPair.includes(part.refDes) ? "is-path" : ""}`}
                      >
                        <rect
                          x={part.bbox.xmin}
                          y={part.bbox.ymin}
                          width={part.bbox.xmax - part.bbox.xmin}
                          height={part.bbox.ymax - part.bbox.ymin}
                          rx="5"
                          tabIndex={0}
                          role="button"
                          aria-label={`Select ${part.refDes}, ${part.marking || part.category}`}
                          onKeyDown={(event) => {
                            if (busy) return;
                            if (event.key === "Enter" || event.key === " ") {
                              event.preventDefault();
                              if (mode === "PROBE" && part.pinSpecs[0])
                                placeProbe({
                                  compRefDes: part.refDes,
                                  pinNumber: part.pinSpecs[0].pinNumber,
                                });
                              else selectPart(part, event.shiftKey);
                            } else if (
                              mode === "SELECT" &&
                              [
                                "ArrowLeft",
                                "ArrowRight",
                                "ArrowUp",
                                "ArrowDown",
                              ].includes(event.key)
                            ) {
                              event.preventDefault();
                              const step = event.shiftKey ? 10 : 1;
                              const dx =
                                event.key === "ArrowRight"
                                  ? step
                                  : event.key === "ArrowLeft"
                                    ? -step
                                    : 0;
                              const dy =
                                event.key === "ArrowDown"
                                  ? step
                                  : event.key === "ArrowUp"
                                    ? -step
                                    : 0;
                              const x = clamp(
                                part.bbox.xmin + dx,
                                0,
                                1000 - part.bbox.xmax + part.bbox.xmin,
                              );
                              const y = clamp(
                                part.bbox.ymin + dy,
                                0,
                                1000 - part.bbox.ymax + part.bbox.ymin,
                              );
                              commit((b) =>
                                movePart(b, part.refDes, {
                                  xmin: x,
                                  ymin: y,
                                  xmax: x + part.bbox.xmax - part.bbox.xmin,
                                  ymax: y + part.bbox.ymax - part.bbox.ymin,
                                }),
                              );
                            }
                          }}
                          onPointerDown={(event) => {
                            if (
                              busy ||
                              event.button !== 0 ||
                              !canvasRef.current ||
                              mode === "PAN" ||
                              mode === "CROP"
                            )
                              return;
                            event.stopPropagation();
                            if (mode === "PROBE") {
                              if (part.pinSpecs[0])
                                placeProbe({
                                  compRefDes: part.refDes,
                                  pinNumber: part.pinSpecs[0].pinNumber,
                                });
                              return;
                            }
                            selectPart(part, event.shiftKey);
                            if (mode !== "SELECT" || event.shiftKey) return;
                            const rect =
                              canvasRef.current.getBoundingClientRect();
                            capture(event, {
                              type: "PART",
                              ref: part.refDes,
                              resize: false,
                              start: toNorm(event.clientX, event.clientY, rect),
                              baseline: stateRef.current.present,
                              rect,
                              pointerId: event.pointerId,
                            });
                          }}
                        />
                        <text
                          x={part.bbox.xmin + 7}
                          y={part.bbox.ymin + 17}
                          className="pcb-part-label pcb-no-pointer"
                        >
                          {part.refDes}
                        </text>
                        <text
                          x={part.bbox.xmin + 7}
                          y={part.bbox.ymin + 32}
                          className="pcb-part-marking pcb-no-pointer"
                        >
                          {(part.marking || part.category).slice(0, 18)}
                        </text>
                        {layers.thermal &&
                          diagnostics?.thermal?.[part.refDes] && (
                            <text
                              x={part.bbox.xmin + 7}
                              y={part.bbox.ymax - 8}
                              className="pcb-part-label pcb-no-pointer"
                            >
                              {diagnostics.thermal[part.refDes]!.tempC.toFixed(
                                1,
                              )}
                              °C
                            </text>
                          )}
                        {selection === part.refDes && mode === "SELECT" && (
                          <rect
                            className="pcb-resize"
                            x={part.bbox.xmax - 5}
                            y={part.bbox.ymax - 5}
                            width="10"
                            height="10"
                            onPointerDown={(event) => {
                              if (
                                busy ||
                                event.button !== 0 ||
                                !canvasRef.current
                              )
                                return;
                              const rect =
                                canvasRef.current.getBoundingClientRect();
                              capture(event, {
                                type: "PART",
                                ref: part.refDes,
                                resize: true,
                                start: toNorm(
                                  event.clientX,
                                  event.clientY,
                                  rect,
                                ),
                                baseline: stateRef.current.present,
                                rect,
                                pointerId: event.pointerId,
                              });
                            }}
                          />
                        )}
                      </g>
                    ))}
                  {layers.pins &&
                    board.components.flatMap((part) =>
                      part.pinSpecs.map((pin, index) => {
                        const pt = pinPoint(part, index);
                        const reading = voltageFor(pin, diagnostics);
                        return (
                          <g
                            key={`${part.refDes}-${pin.pinNumber}`}
                            className="pcb-pin"
                            onPointerEnter={() => {
                              setHoverNet(
                                pin.connectedNetId === UNASSIGNED
                                  ? null
                                  : pin.connectedNetId,
                              );
                              setHoverPin({
                                compRefDes: part.refDes,
                                pinNumber: pin.pinNumber,
                              });
                            }}
                            onPointerLeave={() => {
                              setHoverNet(null);
                              setHoverPin(null);
                            }}
                          >
                            <circle
                              cx={pt.x}
                              cy={pt.y}
                              r="6"
                              fill={colorFor(pin.connectedNetId)}
                              stroke="#061411"
                              strokeWidth="2"
                              tabIndex={0}
                              role="button"
                              aria-label={`${part.refDes} pin ${pin.pinNumber}, ${pin.pinName}, ${reading.value.toFixed(2)} volts ${reading.source}`}
                              onFocus={() =>
                                setHoverPin({
                                  compRefDes: part.refDes,
                                  pinNumber: pin.pinNumber,
                                })
                              }
                              onBlur={() => setHoverPin(null)}
                              onClick={(event) => {
                                if (!busy && mode !== "PAN" && mode !== "CROP")
                                  pinClick(part, pin, event.shiftKey);
                              }}
                              onKeyDown={(event) => {
                                if (
                                  !busy &&
                                  (event.key === "Enter" || event.key === " ")
                                ) {
                                  event.preventDefault();
                                  pinClick(part, pin, event.shiftKey);
                                }
                              }}
                              onPointerDown={(event) => {
                                if (mode !== "PAN" && mode !== "CROP")
                                  event.stopPropagation();
                              }}
                            />
                            <title>
                              {part.refDes} #{pin.pinNumber}: {pin.pinName} ·{" "}
                              {pin.connectedNetId} · {reading.value.toFixed(3)}{" "}
                              V ({reading.source})
                            </title>
                            {layers.voltages && (
                              <text
                                x={pt.x + 10}
                                y={pt.y - 7}
                                className="pcb-voltage pcb-no-pointer"
                              >
                                {reading.value.toFixed(2)}V{" "}
                                {reading.source === "NOMINAL"
                                  ? "nom."
                                  : reading.source}
                              </text>
                            )}
                          </g>
                        );
                      }),
                    )}
                  {path && (
                    <polyline
                      className="pcb-connectivity pcb-no-pointer"
                      points={path.points.map((p) => `${p.x},${p.y}`).join(" ")}
                    />
                  )}
                  {[probeA, probeB].map(
                    (probe, i) =>
                      probe && (
                        <g key={i} className="pcb-no-pointer">
                          <circle
                            cx={probe.point.x}
                            cy={probe.point.y}
                            r="15"
                            fill="none"
                            stroke={i === 0 ? "#fb7185" : "#f8fafc"}
                            strokeWidth="3"
                          />
                          <text
                            x={probe.point.x + 20}
                            y={probe.point.y}
                            className="pcb-probe-label"
                          >
                            {i === 0 ? "A+" : "B−"}
                          </text>
                        </g>
                      ),
                  )}
                  {crop && (
                    <rect
                      className="pcb-crop pcb-no-pointer"
                      x={crop.xmin}
                      y={crop.ymin}
                      width={crop.xmax - crop.xmin}
                      height={crop.ymax - crop.ymin}
                    />
                  )}
                </svg>
                {!board.components.length && !imageDataUrl && (
                  <div className="pcb-empty-board">
                    <Layers size={36} />
                    <h2>Your inspection starts here</h2>
                    <p>
                      Upload a board photo or load the included reference
                      preset.
                    </p>
                    <span>
                      Images remain in this browser unless an analysis or
                      storage adapter is connected.
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className="pcb-canvas-footer">
            <span>
              <i />
              NORMALIZED 0–1000 · {board.aspect.toFixed(3)}:1
            </span>
            <span>
              {mode === "PROBE"
                ? `Next: Probe ${nextProbe === 0 ? "A+" : "B−"}`
                : "F fit · V select · H pan · P probe · Ctrl/Cmd+Z undo"}
            </span>
          </div>
        </main>
        <aside
          className={`pcb-inspector ${mobilePanel !== "INSPECTOR" ? "pcb-mobile-hidden" : ""}`}
          aria-label="Board inspector"
        >
          <nav className="pcb-inspector-tabs" aria-label="Inspector sections">
            {(["PART", "NETS", "PROBE", "AUDIT", "THERMAL"] as Tab[]).map(
              (t) => (
                <button
                  key={t}
                  className={tab === t ? "active" : ""}
                  aria-pressed={tab === t}
                  onClick={() => setTab(t)}
                >
                  {t === "THERMAL" ? "IR" : t}
                  {t === "AUDIT" && findings.length > 0 && (
                    <span>{findings.length}</span>
                  )}
                </button>
              ),
            )}
          </nav>
          <div className="pcb-inspector-content">
            <fieldset disabled={busy} className="pcb-fieldset">
              {tab === "PART" &&
                (selected ? (
                  <>
                    <div className="pcb-section-heading">
                      <div>
                        <div className="pcb-eyebrow">COMPONENT INSPECTOR</div>
                        <h2>
                          {selected.refDes}
                          <span>{selected.category.replace(/_/g, " ")}</span>
                        </h2>
                      </div>
                      <button
                        onClick={deleteSelected}
                        aria-label={`Remove ${selected.refDes}`}
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                    <div
                      className={`pcb-verification ${selected.verificationStatus === "VERIFIED" ? "verified" : ""}`}
                    >
                      <CheckCircle2 size={14} />
                      {selected.verificationStatus === "VERIFIED"
                        ? "Technician verified"
                        : "Unverified observation"}
                    </div>
                    <div className="pcb-field-grid">
                      <Field
                        label="Marking"
                        value={selected.marking}
                        onCommit={(value) =>
                          editPart(selected.refDes, { marking: value })
                        }
                      />
                      <Field
                        label="Package"
                        value={selected.packageType}
                        onCommit={(value) =>
                          editPart(selected.refDes, { packageType: value })
                        }
                      />
                      <Field
                        label="Decoded value"
                        value={selected.decodedValue}
                        onCommit={(value) =>
                          editPart(selected.refDes, { decodedValue: value })
                        }
                      />
                      <Field
                        label="Operating range"
                        value={selected.operatingVoltageRange ?? ""}
                        onCommit={(value) =>
                          editPart(selected.refDes, {
                            operatingVoltageRange: value,
                          })
                        }
                      />
                    </div>
                    {(selected.datasheetSummary ||
                      selected.circuitFunction ||
                      selected.notes) && (
                      <p className="pcb-note">
                        {selected.datasheetSummary ||
                          selected.circuitFunction ||
                          selected.notes}
                      </p>
                    )}
                    <div className="pcb-inline-actions">
                      <button
                        disabled={!onOpenGroundedSearch}
                        onClick={() =>
                          onOpenGroundedSearch?.(
                            `${selected.marking || selected.decodedValue} ${selected.category} datasheet pinout`,
                            "",
                            selected.refDes,
                          )
                        }
                      >
                        <ExternalLink size={14} />
                        Datasheet lookup
                      </button>
                      <button
                        disabled={!onOpenOfflineBot}
                        onClick={() =>
                          onOpenOfflineBot?.(
                            `Review ${selected.refDes} (${selected.marking || selected.category}). Function: ${selected.circuitFunction || "unconfirmed"}. Explain safe, unpowered diagnostic checks and required datasheet verification.`,
                          )
                        }
                      >
                        <Bot size={14} />
                        Diagnostic assistant
                      </button>
                    </div>
                    <div className="pcb-subheading">
                      <h3>Pinout & readings</h3>
                      <button
                        onClick={() =>
                          commit((b) =>
                            reconcileNets({
                              ...b,
                              components: b.components.map((p) =>
                                p.refDes !== selected.refDes
                                  ? p
                                  : {
                                      ...p,
                                      verificationStatus: "UNVERIFIED",
                                      pinSpecs: [
                                        ...p.pinSpecs,
                                        {
                                          pinNumber:
                                            Math.max(
                                              0,
                                              ...p.pinSpecs.map(
                                                (pin) => pin.pinNumber,
                                              ),
                                            ) + 1,
                                          pinName: "UNSPECIFIED",
                                          category: "signal_in",
                                          nominalVoltage: 0,
                                          connectedNetId: UNASSIGNED,
                                        },
                                      ],
                                    },
                              ),
                            }),
                          )
                        }
                      >
                        <Plus size={12} />
                        Pin
                      </button>
                    </div>
                    <div className="pcb-pin-editor">
                      {selected.pinSpecs.map((pin) => {
                        const reading = voltageFor(pin, diagnostics);
                        return (
                          <div
                            className="pcb-pin-card"
                            key={`${selected.refDes}-${pin.pinNumber}`}
                          >
                            <div className="pcb-pin-card-heading">
                              <strong>#{pin.pinNumber}</strong>
                              <span>
                                {reading.value.toFixed(3)} V{" "}
                                <small>{reading.source}</small>
                              </span>
                              <button
                                onClick={() =>
                                  placeProbe({
                                    compRefDes: selected.refDes,
                                    pinNumber: pin.pinNumber,
                                  })
                                }
                                aria-label={`Probe ${selected.refDes} pin ${pin.pinNumber}`}
                              >
                                <Crosshair size={13} />
                              </button>
                            </div>
                            <div className="pcb-field-grid">
                              <Field
                                label="Signal"
                                value={pin.pinName}
                                onCommit={(value) =>
                                  changePin(pin, { pinName: value })
                                }
                              />
                              <Field
                                label="Nominal V"
                                numeric
                                value={pin.nominalVoltage}
                                onCommit={(value) => {
                                  const n = Number(value);
                                  if (value.trim() && Number.isFinite(n))
                                    changePin(pin, { nominalVoltage: n });
                                  else
                                    setStatus(
                                      "Nominal voltage must be a finite number.",
                                    );
                                }}
                              />
                            </div>
                            <Field
                              label="Net ID"
                              value={pin.connectedNetId}
                              onCommit={(value) =>
                                changePin(pin, {
                                  connectedNetId: normalizeNetName(value),
                                })
                              }
                            />
                          </div>
                        );
                      })}
                    </div>
                    <button
                      className="pcb-full-button"
                      onClick={() =>
                        commit((b) => ({
                          ...b,
                          components: b.components.map((p) =>
                            p.refDes === selected.refDes
                              ? {
                                  ...p,
                                  verificationStatus:
                                    p.verificationStatus === "VERIFIED"
                                      ? "UNVERIFIED"
                                      : "VERIFIED",
                                }
                              : p,
                          ),
                        }))
                      }
                    >
                      <CheckCircle2 size={15} />
                      {selected.verificationStatus === "VERIFIED"
                        ? "Revoke technician sign-off"
                        : "Sign off verified observation"}
                    </button>
                  </>
                ) : (
                  <div className="pcb-panel-empty">
                    <MousePointer2 size={28} />
                    <h3>Select a component</h3>
                    <p>
                      Use the canvas or registry below to inspect a part and
                      edit its pin mapping.
                    </p>
                  </div>
                ))}
              {tab === "NETS" && (
                <>
                  <div className="pcb-section-heading">
                    <h2>Copper net registry</h2>
                    <span>{board.nets.length}</span>
                  </div>
                  <p className="pcb-note">
                    Routes below are editable schematic geometry, not evidence
                    of copper hidden by solder mask or inner layers.
                  </p>
                  {board.nets.map((net) => (
                    <div
                      className={`pcb-net-card ${effectiveNet === net.name ? "active" : ""}`}
                      key={net.name}
                    >
                      <button onClick={() => setActiveNet(net.name)}>
                        <i style={{ backgroundColor: colorFor(net.name) }} />
                        <strong>{net.name}</strong>
                      </button>
                      <p>
                        {net.connectedComponentRefs.join(", ") ||
                          "No assigned component pins"}
                      </p>
                      <div className="pcb-inline-actions">
                        <button
                          disabled={net.connectedTerminalIds.length < 2}
                          onClick={() => commit((b) => routeNet(b, net.name))}
                        >
                          Schematic auto-route
                        </button>
                        <button
                          onClick={() => {
                            commit((b) => ({
                              ...b,
                              nets: b.nets.map((n) => {
                                if (n.name !== net.name) return n;
                                const next = branches(n).map((br) => [...br]);
                                if (!next.length)
                                  next.push([{ x: 500, y: 500 }]);
                                const last = next.at(-1)!;
                                const p = last.at(-1) ?? { x: 500, y: 500 };
                                last.push({
                                  x: clamp(p.x + 35),
                                  y: clamp(p.y + 35),
                                });
                                return withBranches(n, next);
                              }),
                            }));
                            setMode("TRACE");
                          }}
                        >
                          + Vertex
                        </button>
                        <button
                          onClick={() =>
                            commit((b) => ({
                              ...b,
                              nets: b.nets.map((n) =>
                                n.name !== net.name
                                  ? n
                                  : withBranches(
                                      n,
                                      branches(n).map((br, i, all) =>
                                        i === all.length - 1 && br.length > 2
                                          ? br.slice(0, -1)
                                          : br,
                                      ),
                                    ),
                              ),
                            }))
                          }
                        >
                          − Vertex
                        </button>
                      </div>
                    </div>
                  ))}
                </>
              )}
              {tab === "PROBE" && (
                <>
                  <div className="pcb-section-heading">
                    <h2>Dual-probe meter</h2>
                    <Crosshair size={20} />
                  </div>
                  <p className="pcb-note">
                    Nominal values are specifications—not measurements. Physical
                    resistance, continuity, and diode Vf require a de-energized
                    board and a suitable meter; this workspace does not invent
                    those readings.
                  </p>
                  <div className="pcb-probe-grid">
                    {[probeA, probeB].map((probe, index) => (
                      <button
                        className={`pcb-probe-card ${nextProbe === index ? "active" : ""}`}
                        key={index}
                        onClick={() => {
                          setNextProbe(index === 0 ? 0 : 1);
                          setMode("PROBE");
                        }}
                      >
                        <small>PROBE {index === 0 ? "A (+)" : "B (−)"}</small>
                        <strong>
                          {probe
                            ? `${probe.part.refDes} #${probe.pin.pinNumber}`
                            : "Select a pin"}
                        </strong>
                        <span>
                          {probe ? probe.pin.connectedNetId : "Not placed"}
                        </span>
                      </button>
                    ))}
                  </div>
                  <div className="pcb-meter">
                    <small>
                      {differentialValid
                        ? `${vA.source} DIFFERENTIAL · A − B`
                        : "NO COMPARABLE LIVE / MEASURED DATA"}
                    </small>
                    <strong>
                      {differentialValid
                        ? `${vA.value - vB.value >= 0 ? "+" : ""}${(vA.value - vB.value).toFixed(3)} V`
                        : "—"}
                    </strong>
                    <span>
                      {probeA && probeB
                        ? probeA.pin.connectedNetId !== UNASSIGNED &&
                          probeA.pin.connectedNetId ===
                            probeB.pin.connectedNetId
                          ? "Same mapped net · physical continuity unverified"
                          : "Different or unassigned mapped nets"
                        : "Place both probes to compare"}
                    </span>
                  </div>
                  <div className="pcb-inline-actions">
                    <button onClick={() => setProbeTargets(([a, b]) => [b, a])}>
                      Swap polarity
                    </button>
                    <button
                      onClick={() => {
                        setProbeTargets([null, null]);
                        setNextProbe(0);
                      }}
                    >
                      Clear probes
                    </button>
                  </div>
                </>
              )}
              {tab === "AUDIT" && (
                <>
                  <div className="pcb-section-heading">
                    <h2>Inspection audit</h2>
                    <AlertTriangle size={19} />
                  </div>
                  <p className="pcb-note">
                    These are map-quality checks plus findings supplied by your
                    diagnostic engine—not an electrical safety certification.
                  </p>
                  {!findings.length && (
                    <p>
                      No map-quality findings. This does not establish that the
                      PCB is fault-free.
                    </p>
                  )}
                  {findings.map((finding, index) => (
                    <button
                      className={`pcb-finding pcb-severity-${finding.severity.toLowerCase()}`}
                      key={`${finding.id}-${index}`}
                      onClick={() => {
                        if (finding.targetCompRef)
                          setSelection(finding.targetCompRef);
                        if (finding.targetNetId)
                          setActiveNet(finding.targetNetId);
                      }}
                    >
                      <small>{finding.severity}</small>
                      <strong>{finding.title}</strong>
                      <span>{finding.detail}</span>
                    </button>
                  ))}
                  <div className="pcb-subheading">
                    <h3>Physical inspection flags</h3>
                    <button
                      onClick={() => {
                        const box = selected?.bbox ?? {
                          xmin: 400,
                          ymin: 400,
                          xmax: 600,
                          ymax: 600,
                        };
                        commit((b) => ({
                          ...b,
                          hotspots: [
                            ...b.hotspots,
                            {
                              id: crypto.randomUUID(),
                              label: selected
                                ? `${selected.refDes} inspection flag`
                                : "Manual inspection region",
                              severity: "WARNING",
                              bbox: box,
                              suspectComponentRef: selected?.refDes,
                              source: "MANUAL",
                              notes:
                                "Technician flagged for follow-up inspection; fault not confirmed.",
                            },
                          ],
                        }));
                      }}
                    >
                      + Flag
                    </button>
                  </div>
                  {board.hotspots.map((h) => (
                    <div className="pcb-hotspot-card" key={h.id}>
                      <strong>{h.label}</strong>
                      <span>
                        {h.severity} · {h.source}
                      </span>
                      <button
                        aria-label={`Remove ${h.label}`}
                        onClick={() =>
                          commit((b) => ({
                            ...b,
                            hotspots: b.hotspots.filter((p) => p.id !== h.id),
                          }))
                        }
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  ))}
                </>
              )}
              {tab === "THERMAL" && (
                <>
                  <div className="pcb-section-heading">
                    <h2>Thermal telemetry</h2>
                    <Flame size={20} />
                  </div>
                  <p className="pcb-note">
                    Visible-light photographs cannot measure junction
                    temperature. Connect simulated results or thermal sensor
                    readings through the diagnostic adapter; each value is
                    labeled by source.
                  </p>
                  {!thermalValues.length && (
                    <div className="pcb-panel-empty">
                      No thermal data connected.
                    </div>
                  )}
                  {board.components.map((part) => {
                    const t = diagnostics?.thermal?.[part.refDes];
                    return t && Number.isFinite(t.tempC) ? (
                      <button
                        className="pcb-thermal-card"
                        key={part.refDes}
                        onClick={() => {
                          setSelection(part.refDes);
                          setLayers((l) => ({ ...l, thermal: true }));
                        }}
                      >
                        <strong>
                          {part.refDes} <small>{t.source}</small>
                        </strong>
                        <span>
                          {t.tempC.toFixed(1)}°C ·{" "}
                          {t.powerDissipationMw.toFixed(1)} mW
                        </span>
                        <meter
                          min={thermalMin}
                          max={thermalMax}
                          value={t.tempC}
                        />
                        <p>{t.note}</p>
                      </button>
                    ) : null;
                  })}
                </>
              )}
            </fieldset>
          </div>
          <div className="pcb-registry">
            <div className="pcb-subheading">
              <h3>Part registry</h3>
              <span>
                {visibleParts.length} / {board.components.length}
              </span>
            </div>
            <div className="pcb-search">
              <Search size={14} />
              <input
                aria-label="Search components"
                value={query}
                placeholder="Reference, marking, value…"
                onChange={(event) => setQuery(event.target.value)}
              />
            </div>
            <select
              value={filter}
              aria-label="Filter by verification"
              onChange={(event) => setFilter(event.target.value)}
            >
              <option value="ALL">All observations</option>
              <option value="VERIFIED">Technician verified</option>
              <option value="UNVERIFIED">Unverified</option>
            </select>
            <div className="pcb-registry-list">
              {visibleParts.map((part) => (
                <button
                  disabled={busy}
                  key={part.refDes}
                  className={selection === part.refDes ? "active" : ""}
                  onClick={() => selectPart(part)}
                >
                  <strong>{part.refDes}</strong>
                  <span>{part.marking || part.category}</span>
                  <small>
                    {part.verificationStatus === "VERIFIED"
                      ? "VERIFIED"
                      : part.source}
                  </small>
                </button>
              ))}
              {!visibleParts.length && <p>No matching components.</p>}
            </div>
          </div>
        </aside>
      </div>
      <footer
        className="pcb-status"
        role="status"
        aria-live="polite"
        aria-atomic="true"
      >
        <span className={busy ? "pcb-spinner" : "pcb-status-dot"} />
        <span>{status}</span>
        {busy && <button onClick={cancelOperation}>Cancel</button>}
        <small>{board.model}</small>
      </footer>
      {hover && !dragRef.current && (
        <div className="pcb-node-tooltip" role="status">
          <strong>
            {hover.part.refDes} · #{hover.pin.pinNumber} {hover.pin.pinName}
          </strong>
          <span>
            {voltageFor(hover.pin, diagnostics).value.toFixed(3)} V ·{" "}
            {voltageFor(hover.pin, diagnostics).source}
          </span>
          <small>{hover.pin.connectedNetId}</small>
        </div>
      )}
    </section>
  );
}
export default PcbWorkspace;
