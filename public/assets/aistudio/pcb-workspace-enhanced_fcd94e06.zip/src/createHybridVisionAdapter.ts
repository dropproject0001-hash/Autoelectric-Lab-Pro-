import { decodeBoard, type Board, type Box } from "./pcbModel";
import type { PcbServices, ScanContext } from "./pcbServices";

/**
 * Connects the functions in the pasted project without importing its private modules.
 * Type parameters are inferred from the real utilities when you supply them.
 *
 * Example (inside YOUR repository; adjust relative paths):
 *
 * const vision = createHybridVisionAdapter({
 *   analyze: analyzePcbImage,
 *   crop: cropPcbRegionToJpegBase64,
 *   fuse: fusePcbVisionResults,
 *   merge: mergeMacroCropResults,
 *   // Bridge this package's normalized model to your engine's richer interfaces.
 *   toLegacyBoard: board => ({
 *     components: board.components.map(toImageAnalysisComponent),
 *     nets: board.nets.map(toExtendedImageAnalysisNet),
 *     hotspots: board.hotspots.map(toImageAnalysisHotspot),
 *   }),
 * });
 * const services = { ...vision, ...authenticatedStorageAdapter };
 *
 * toImageAnalysisComponent / toExtendedImageAnalysisNet / toImageAnalysisHotspot
 * are explicit mapping functions YOU implement against your actual interfaces.
 * They are not missing runtime dependencies of this adapter.
 *
 * The original utilities may not accept AbortSignal. Results are still guarded
 * after each await; actual transport cancellation needs signal support server-side.
 */
export interface LegacyVisionDependencies<
  Analysis extends { detectionMethod?: string },
  LocalCv,
  Fused,
  LegacyBoard,
> {
  analyze(input: {
    imageBase64: string;
    mimeType: string;
    documentName: string;
    documentType: string;
    regionBox?: Box;
  }): Promise<Analysis>;
  crop(
    imageUrl: string,
    crop: Box,
  ): Promise<{ imageBase64: string; mimeType: string; localCv: LocalCv }>;
  fuse(ai: Analysis | null, local: LocalCv): Fused;
  merge(board: LegacyBoard, crop: Box, result: Fused): unknown;
  toLegacyBoard(board: Board): LegacyBoard;
}
function check(signal: AbortSignal): void {
  if (signal.aborted) throw new DOMException("Operation aborted", "AbortError");
}
export function createHybridVisionAdapter<
  Analysis extends { detectionMethod?: string },
  LocalCv,
  Fused,
  LegacyBoard,
>(
  dependencies: LegacyVisionDependencies<Analysis, LocalCv, Fused, LegacyBoard>,
): Pick<PcbServices, "analyzeImage" | "analyzeRegion"> {
  const run = async (
    context: ScanContext,
    region?: { crop: Box; board: Board },
  ): Promise<Board> => {
    check(context.signal);
    const dataUrl = `data:${context.mimeType};base64,${context.imageBase64}`;
    const box = region?.crop ?? { xmin: 0, ymin: 0, xmax: 1000, ymax: 1000 };
    context.onProgress("Running local image analysis…");
    const prepared = await dependencies.crop(dataUrl, box);
    check(context.signal);
    let ai: Analysis | null = null;
    context.onProgress(
      "Mapping components with the configured vision service…",
    );
    try {
      ai = await dependencies.analyze({
        imageBase64: prepared.imageBase64,
        mimeType: prepared.mimeType,
        documentName: context.documentName,
        documentType: region ? "pcb_macro_crop" : "pcb",
        ...(region ? { regionBox: region.crop } : {}),
      });
    } catch (error) {
      check(context.signal);
      // AI outage is not an upload/decode failure: keep the deterministic fallback.
      context.onProgress(
        `AI unavailable; preserving local CV fallback (${error instanceof Error ? error.message : "service error"}).`,
      );
    }
    check(context.signal);
    const fused = dependencies.fuse(
      ai?.detectionMethod === "AI_ANALYZED" ? ai : null,
      prepared.localCv,
    );
    const value = region
      ? dependencies.merge(
          dependencies.toLegacyBoard(region.board),
          region.crop,
          fused,
        )
      : fused;
    check(context.signal);
    if (!value || typeof value !== "object")
      throw new Error("Vision pipeline returned no board map");
    return decodeBoard({
      ...(region?.board ?? {}),
      ...value,
      title:
        region?.board.title ?? context.documentName.replace(/\.[^.]+$/, ""),
    });
  };
  return {
    analyzeImage: (context) => run(context),
    analyzeRegion: (context) =>
      run(context, { crop: context.crop, board: context.board }),
  };
}
