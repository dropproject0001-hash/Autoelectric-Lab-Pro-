import { useCallback, useRef, useState } from "react";
import type { Board } from "./pcbModel";

export interface BoardDocument {
  board: Board;
  imageDataUrl: string | null;
}
export interface HistoryState {
  past: BoardDocument[];
  present: BoardDocument;
  future: BoardDocument[];
  revision: number;
}
export type HistoryAction =
  | { type: "commit"; document: BoardDocument }
  | { type: "preview"; document: BoardDocument }
  | { type: "finish"; baseline: BoardDocument }
  | { type: "reset"; document: BoardDocument }
  | { type: "undo" | "redo" };
const LIMIT = 40;
export function reduceHistory(
  state: HistoryState,
  action: HistoryAction,
): HistoryState {
  switch (action.type) {
    case "commit":
      if (action.document === state.present) return state;
      return {
        past: [...state.past, state.present].slice(-LIMIT),
        present: action.document,
        future: [],
        revision: state.revision + 1,
      };
    case "preview":
      return {
        ...state,
        present: action.document,
        revision: state.revision + 1,
      };
    case "finish":
      if (state.present === action.baseline) return state;
      return {
        ...state,
        past: [...state.past, action.baseline].slice(-LIMIT),
        future: [],
        revision: state.revision + 1,
      };
    case "reset":
      return {
        past: [],
        present: action.document,
        future: [],
        revision: state.revision + 1,
      };
    case "undo": {
      const previous = state.past.at(-1);
      return previous
        ? {
            past: state.past.slice(0, -1),
            present: previous,
            future: [state.present, ...state.future].slice(0, LIMIT),
            revision: state.revision + 1,
          }
        : state;
    }
    case "redo": {
      const next = state.future[0];
      return next
        ? {
            past: [...state.past, state.present].slice(-LIMIT),
            present: next,
            future: state.future.slice(1),
            revision: state.revision + 1,
          }
        : state;
    }
  }
}
/** Synchronous ref mirrors state so pointerup cannot observe a previous render. */
export function useBoardHistory(initial: BoardDocument) {
  const [state, setState] = useState<HistoryState>(() => ({
    past: [],
    present: initial,
    future: [],
    revision: 0,
  }));
  const stateRef = useRef(state);
  const dispatch = useCallback((action: HistoryAction) => {
    stateRef.current = reduceHistory(stateRef.current, action);
    setState(stateRef.current);
  }, []);
  const commit = useCallback(
    (update: (board: Board) => Board) => {
      const current = stateRef.current.present;
      const next = update(current.board);
      if (next !== current.board)
        dispatch({ type: "commit", document: { ...current, board: next } });
    },
    [dispatch],
  );
  return { state, stateRef, dispatch, commit };
}
