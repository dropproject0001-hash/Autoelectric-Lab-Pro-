import { decodeBoard, type Board } from "./pcbModel";
const pin = (
  pinNumber: number,
  pinName: string,
  connectedNetId: string,
  nominalVoltage: number,
) => ({
  pinNumber,
  pinName,
  connectedNetId,
  nominalVoltage,
  category: nominalVoltage === 0 ? "ground" : "signal_in",
});
const part = (
  refDes: string,
  category: string,
  marking: string,
  bbox: Board["components"][number]["bbox"],
  pinSpecs: Board["components"][number]["pinSpecs"],
) => ({
  refDes,
  category,
  marking,
  bbox,
  pinSpecs,
  decodedValue: "Illustrative reference only",
  packageType: "Generic footprint",
  verificationStatus: "UNVERIFIED",
  source: "DEMO",
  confidenceScore: 1,
});
export const demoBoard = decodeBoard({
  id: "demo-power-stage",
  title: "Power stage · reference layout",
  boardType: "Illustrative automotive power stage",
  analysisSummary:
    "Synthetic reference map for interaction testing. Not an OEM schematic or a verified device pinout.",
  model: "illustrative-reference",
  aspect: 1.5,
  components: [
    part(
      "J1",
      "CONNECTOR",
      "BENCH INPUT",
      { xmin: 75, ymin: 220, xmax: 210, ymax: 430 },
      [pin(1, "VBAT", "NET_VBAT", 12.6), pin(2, "GND", "NET_GND", 0)],
    ),
    part(
      "D1",
      "DIODE",
      "INPUT PROTECTION",
      { xmin: 290, ymin: 250, xmax: 415, ymax: 360 },
      [
        pin(1, "INPUT", "NET_VBAT", 12.6),
        pin(2, "OUTPUT", "NET_PROTECTED", 12.2),
      ],
    ),
    part(
      "U1",
      "VOLTAGE_REGULATOR",
      "GENERIC 5V LDO",
      { xmin: 490, ymin: 215, xmax: 675, ymax: 465 },
      [
        pin(1, "VIN", "NET_PROTECTED", 12.2),
        pin(2, "GND", "NET_GND", 0),
        pin(3, "VOUT", "NET_5V", 5),
      ],
    ),
    part(
      "C1",
      "CAPACITOR",
      "DECOUPLING",
      { xmin: 305, ymin: 600, xmax: 420, ymax: 720 },
      [pin(1, "RAIL", "NET_PROTECTED", 12.2), pin(2, "RETURN", "NET_GND", 0)],
    ),
    part(
      "TP1",
      "TEST_POINT",
      "5V TEST PAD",
      { xmin: 775, ymin: 285, xmax: 890, ymax: 400 },
      [pin(1, "PAD", "NET_5V", 5)],
    ),
    part(
      "R1",
      "RESISTOR",
      "LOAD / TEST",
      { xmin: 735, ymin: 615, xmax: 880, ymax: 730 },
      [pin(1, "RAIL", "NET_5V", 5), pin(2, "RETURN", "NET_GND", 0)],
    ),
  ],
  nets: [
    {
      name: "NET_VBAT",
      tracePoints: [
        { x: 75, y: 290 },
        { x: 45, y: 290 },
        { x: 45, y: 170 },
        { x: 260, y: 170 },
        { x: 260, y: 305 },
        { x: 290, y: 305 },
      ],
    },
    {
      name: "NET_PROTECTED",
      traceBranches: [
        [
          { x: 415, y: 305 },
          { x: 455, y: 305 },
          { x: 455, y: 298.33 },
          { x: 490, y: 298.33 },
        ],
        [
          { x: 455, y: 305 },
          { x: 455, y: 555 },
          { x: 280, y: 555 },
          { x: 280, y: 660 },
          { x: 305, y: 660 },
        ],
      ],
    },
    {
      name: "NET_5V",
      traceBranches: [
        [
          { x: 675, y: 340 },
          { x: 720, y: 340 },
          { x: 720, y: 342.5 },
          { x: 775, y: 342.5 },
        ],
        [
          { x: 720, y: 340 },
          { x: 720, y: 672.5 },
          { x: 735, y: 672.5 },
        ],
      ],
    },
    {
      name: "NET_GND",
      traceBranches: [
        [
          { x: 210, y: 325 },
          { x: 240, y: 325 },
          { x: 240, y: 800 },
          { x: 925, y: 800 },
          { x: 925, y: 672.5 },
          { x: 880, y: 672.5 },
        ],
        [
          { x: 420, y: 660 },
          { x: 450, y: 660 },
          { x: 450, y: 800 },
        ],
        [
          { x: 490, y: 381.67 },
          { x: 470, y: 381.67 },
          { x: 470, y: 800 },
        ],
      ],
    },
  ],
  hotspots: [
    {
      id: "demo-inspect",
      label: "Inspect input protection joints",
      severity: "INFO",
      bbox: { xmin: 275, ymin: 235, xmax: 430, ymax: 375 },
      suspectComponentRef: "D1",
      source: "DEMO",
      notes: "Illustrative inspection zone, not a detected physical fault.",
    },
  ],
});
