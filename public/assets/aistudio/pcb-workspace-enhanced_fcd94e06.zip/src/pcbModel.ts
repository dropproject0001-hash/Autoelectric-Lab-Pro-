/* Normalized board coordinates are always in [0, 1000].
 * Geometry is descriptive, not proof of electrical connectivity.
 */
export type Point = { x: number; y: number };
export type Box = { xmin: number; ymin: number; xmax: number; ymax: number };
export type Severity = "INFO" | "WARNING" | "CRITICAL";
export type Verification = "UNVERIFIED" | "VERIFIED";
export interface Pin {
  pinNumber: number;
  pinName: string;
  category: string;
  nominalVoltage: number;
  connectedNetId: string;
  notes?: string;
}
export interface Part {
  refDes: string;
  category: string;
  marking: string;
  decodedValue: string;
  packageType: string;
  bbox: Box;
  pinSpecs: Pin[];
  terminalIds: string[];
  verificationStatus: Verification;
  source: string;
  confidenceScore: number;
  notes?: string;
  circuitFunction?: string;
  operatingVoltageRange?: string;
  datasheetSummary?: string;
  maxCurrentRating?: string;
}
export interface Net {
  name: string;
  signalType: string;
  connectedComponentRefs: string[];
  connectedTerminalIds: string[];
  tracePoints: Point[];
  traceBranches?: Point[][];
  nominalVoltage?: number;
  verificationStatus: Verification;
  confidenceScore: number;
  isComplete: boolean;
}
export interface Hotspot {
  id: string;
  label: string;
  severity: Severity;
  bbox: Box;
  suspectComponentRef?: string;
  notes?: string;
  source: string;
}
export interface Board {
  id: string;
  title: string;
  boardType: string;
  analysisSummary: string;
  model: string;
  aspect: number;
  components: Part[];
  nets: Net[];
  hotspots: Hotspot[];
}
export interface ProbeTarget {
  compRefDes: string;
  pinNumber: number;
}
export interface Finding {
  id: string;
  severity: Severity;
  title: string;
  detail: string;
  targetCompRef?: string;
  targetNetId?: string;
}
export const UNASSIGNED = "NET_UNASSIGNED";
export const clamp = (n: number, low = 0, high = 1000): number =>
  Math.min(high, Math.max(low, Number.isFinite(n) ? n : low));
export const center = (b: Box): Point => ({
  x: (b.xmin + b.xmax) / 2,
  y: (b.ymin + b.ymax) / 2,
});
export const terminalId = (ref: string, pin: number): string => `${ref}-${pin}`;
export function normalizeNetName(value: string): string {
  return (
    value
      .trim()
      .toUpperCase()
      .replace(/\s+/g, "_")
      .replace(/[^A-Z0-9_.:+-]/g, "_") || UNASSIGNED
  );
}
export function normalizeBox(b: Box): Box {
  const xmin = clamp(Math.min(b.xmin, b.xmax), 0, 999);
  const ymin = clamp(Math.min(b.ymin, b.ymax), 0, 999);
  return {
    xmin,
    ymin,
    xmax: clamp(Math.max(b.xmin, b.xmax), xmin + 1),
    ymax: clamp(Math.max(b.ymin, b.ymax), ymin + 1),
  };
}
export function pinPoint(part: Part, index: number): Point {
  const count = part.pinSpecs.length;
  const leftCount = Math.ceil(count / 2);
  const left = index < leftCount;
  const sideCount = left ? leftCount : count - leftCount;
  const slot = left ? index : count - 1 - index;
  return {
    x: left ? part.bbox.xmin : part.bbox.xmax,
    y:
      part.bbox.ymin +
      ((slot + 1) / (sideCount + 1)) * (part.bbox.ymax - part.bbox.ymin),
  };
}
export function resolveProbe(
  board: Board,
  target: ProbeTarget | null,
): { part: Part; pin: Pin; point: Point } | null {
  if (!target) return null;
  const part = board.components.find((p) => p.refDes === target.compRefDes);
  if (!part) return null;
  const index = part.pinSpecs.findIndex(
    (p) => p.pinNumber === target.pinNumber,
  );
  const pin = part.pinSpecs[index];
  return pin ? { part, pin, point: pinPoint(part, index) } : null;
}
export const branches = (net: Net): Point[][] =>
  net.traceBranches?.length
    ? net.traceBranches
    : net.tracePoints.length
      ? [net.tracePoints]
      : [];
export function withBranches(net: Net, next: Point[][]): Net {
  return { ...net, traceBranches: next, tracePoints: next.flat() };
}
function makeNet(name: string): Net {
  return {
    name,
    signalType: /GND|GROUND/.test(name) ? "GROUND" : "SIGNAL_TRACE",
    connectedComponentRefs: [],
    connectedTerminalIds: [],
    tracePoints: [],
    confidenceScore: 1,
    verificationStatus: "UNVERIFIED",
    isComplete: false,
  };
}
/** Pins are the authoritative connectivity source. Geometry is retained independently. */
export function reconcileNets(board: Board): Board {
  const map = new Map(
    board.nets.map((n) => [
      n.name,
      {
        ...n,
        connectedComponentRefs: [] as string[],
        connectedTerminalIds: [] as string[],
      },
    ]),
  );
  const components = board.components.map((part) => {
    const pinSpecs = part.pinSpecs.map((pin) => ({
      ...pin,
      connectedNetId: normalizeNetName(pin.connectedNetId),
    }));
    for (const pin of pinSpecs) {
      if (pin.connectedNetId === UNASSIGNED) continue;
      let net = map.get(pin.connectedNetId);
      if (!net) {
        net = makeNet(pin.connectedNetId);
        map.set(net.name, net);
      }
      if (!net.connectedComponentRefs.includes(part.refDes))
        net.connectedComponentRefs.push(part.refDes);
      net.connectedTerminalIds.push(terminalId(part.refDes, pin.pinNumber));
    }
    return {
      ...part,
      pinSpecs,
      terminalIds: pinSpecs.map((p) => terminalId(part.refDes, p.pinNumber)),
    };
  });
  return { ...board, components, nets: [...map.values()] };
}
export function updatePin(
  board: Board,
  ref: string,
  number: number,
  patch: Partial<Pin>,
): Board {
  const components = board.components.map((part) =>
    part.refDes !== ref
      ? part
      : {
          ...part,
          verificationStatus: "UNVERIFIED" as const,
          pinSpecs: part.pinSpecs.map((pin) =>
            pin.pinNumber !== number
              ? pin
              : {
                  ...pin,
                  ...patch,
                  pinNumber: pin.pinNumber,
                  nominalVoltage:
                    patch.nominalVoltage !== undefined &&
                    Number.isFinite(patch.nominalVoltage)
                      ? patch.nominalVoltage
                      : pin.nominalVoltage,
                },
          ),
        },
  );
  return reconcileNets({ ...board, components });
}
export function removePart(board: Board, ref: string): Board {
  return reconcileNets({
    ...board,
    components: board.components.filter((p) => p.refDes !== ref),
    hotspots: board.hotspots.map((h) =>
      h.suspectComponentRef === ref
        ? { ...h, suspectComponentRef: undefined }
        : h,
    ),
  });
}
/** Move only terminal-adjacent geometry, never arbitrary nearby unrelated vertices. */
export function movePart(board: Board, ref: string, nextBox: Box): Board {
  const part = board.components.find((p) => p.refDes === ref);
  if (!part) return board;
  const nextPart = { ...part, bbox: normalizeBox(nextBox) };
  const oldPins = part.pinSpecs.map((pin, i) => ({
    pin,
    point: pinPoint(part, i),
    next: pinPoint(nextPart, i),
  }));
  const nets = board.nets.map((net) =>
    withBranches(
      net,
      branches(net).map((branch) =>
        branch.map((pt) => {
          const match = oldPins.find(
            (p) =>
              p.pin.connectedNetId === net.name &&
              Math.hypot(pt.x - p.point.x, pt.y - p.point.y) <= 3,
          );
          return match ? match.next : pt;
        }),
      ),
    ),
  );
  return {
    ...board,
    components: board.components.map((p) => (p.refDes === ref ? nextPart : p)),
    nets,
  };
}
export function routeNet(board: Board, name: string): Board {
  const pins = board.components.flatMap((part) =>
    part.pinSpecs.flatMap((pin, i) =>
      pin.connectedNetId === name ? [pinPoint(part, i)] : [],
    ),
  );
  const origin = pins[0];
  if (!origin || pins.length < 2) return board;
  const next = pins
    .slice(1)
    .map((pt) => [origin, { x: pt.x, y: origin.y }, pt]);
  return {
    ...board,
    nets: board.nets.map((n) =>
      n.name === name
        ? {
            ...withBranches(n, next),
            isComplete: false,
            verificationStatus: "UNVERIFIED",
          }
        : n,
    ),
  };
}
export type Template =
  | "TEST_POINT"
  | "RESISTOR"
  | "CAPACITOR"
  | "DIODE"
  | "MOSFET_DRIVER"
  | "VOLTAGE_REGULATOR";
/** Generic templates deliberately avoid asserting unverified manufacturer pinouts. */
export function addPart(
  board: Board,
  template: Template,
): { board: Board; ref: string } {
  const prefix = {
    TEST_POINT: "TP",
    RESISTOR: "R",
    CAPACITOR: "C",
    DIODE: "D",
    MOSFET_DRIVER: "Q",
    VOLTAGE_REGULATOR: "U",
  }[template];
  let i = 1;
  while (board.components.some((p) => p.refDes === `${prefix}${i}`)) i++;
  const ref = `${prefix}${i}`;
  const count =
    template === "TEST_POINT"
      ? 1
      : template === "MOSFET_DRIVER" || template === "VOLTAGE_REGULATOR"
        ? 3
        : 2;
  const part: Part = {
    refDes: ref,
    category: template,
    marking: "",
    decodedValue: "Unspecified — verify actual device",
    packageType: "Unspecified",
    bbox: { xmin: 420, ymin: 420, xmax: 570, ymax: 570 },
    confidenceScore: 1,
    verificationStatus: "UNVERIFIED",
    source: "MANUAL",
    terminalIds: [],
    pinSpecs: Array.from({ length: count }, (_, j) => ({
      pinNumber: j + 1,
      pinName: `PIN_${j + 1}`,
      category: "signal_in",
      nominalVoltage: 0,
      connectedNetId: UNASSIGNED,
    })),
  };
  return {
    board: reconcileNets({ ...board, components: [...board.components, part] }),
    ref,
  };
}
export function auditBoard(board: Board): Finding[] {
  const findings: Finding[] = [];
  for (const part of board.components) {
    for (const pin of part.pinSpecs)
      if (pin.connectedNetId === UNASSIGNED)
        findings.push({
          id: `unassigned-${part.refDes}-${pin.pinNumber}`,
          severity: "INFO",
          title: `${part.refDes} pin ${pin.pinNumber} is unassigned`,
          detail:
            "Confirm connectivity with a schematic or physical continuity test.",
          targetCompRef: part.refDes,
        });
  }
  for (const net of board.nets)
    if (net.connectedTerminalIds.length < 2)
      findings.push({
        id: `net-${net.name}`,
        severity: "INFO",
        title: `${net.name} has fewer than two mapped terminals`,
        detail:
          "May be a legitimate external connection or incomplete mapping; not proof of a fault.",
        targetNetId: net.name,
      });
  return findings;
}
/** Draws schematic connectivity only; does not claim to recover physical copper. */
export function connectedPartPath(
  board: Board,
  from: string | null,
  to: string | null,
): { points: Point[]; nets: string[] } | null {
  if (!from || !to || from === to) return null;
  const parts = new Map(board.components.map((p) => [p.refDes, p]));
  if (!parts.has(from) || !parts.has(to)) return null;
  const queue: { ref: string; refs: string[]; nets: string[] }[] = [
    { ref: from, refs: [from], nets: [] },
  ];
  const visited = new Set([from]);
  for (let index = 0; index < queue.length; index++) {
    const item = queue[index];
    if (!item) continue;
    for (const net of board.nets.filter((n) =>
      n.connectedComponentRefs.includes(item.ref),
    )) {
      for (const ref of net.connectedComponentRefs) {
        if (visited.has(ref) || !parts.has(ref)) continue;
        const refs = [...item.refs, ref];
        const nets = [...item.nets, net.name];
        if (ref === to)
          return { points: refs.map((r) => center(parts.get(r)!.bbox)), nets };
        visited.add(ref);
        queue.push({ ref, refs, nets });
      }
    }
  }
  return null;
}

// Strict, bounded schema decoder for imports, presets, and remote results.
const obj = (v: unknown): Record<string, unknown> => {
  if (!v || typeof v !== "object" || Array.isArray(v))
    throw new Error("Expected an object");
  return v as Record<string, unknown>;
};
const text = (v: unknown, fallback = ""): string =>
  typeof v === "string" ? v.slice(0, 10000) : fallback;
const finite = (v: unknown, fallback = 0): number =>
  typeof v === "number" && Number.isFinite(v) ? v : fallback;
function list(v: unknown, max: number): unknown[] {
  if (v === undefined) return [];
  if (!Array.isArray(v) || v.length > max)
    throw new Error(`Expected an array with at most ${max} entries`);
  return v;
}
function strings(v: unknown): string[] {
  return list(v, 10000)
    .map((x) => text(x))
    .filter(Boolean);
}
function box(v: unknown): Box {
  const b = obj(v);
  for (const key of ["xmin", "ymin", "xmax", "ymax"])
    if (typeof b[key] !== "number" || !Number.isFinite(b[key]))
      throw new Error(`Invalid box coordinate: ${key}`);
  return normalizeBox({
    xmin: finite(b.xmin),
    ymin: finite(b.ymin),
    xmax: finite(b.xmax),
    ymax: finite(b.ymax),
  });
}
function points(v: unknown): Point[] {
  return list(v, 20000).map((x) => {
    const p = obj(x);
    return { x: clamp(finite(p.x)), y: clamp(finite(p.y)) };
  });
}
const verification = (v: unknown): Verification =>
  v === "VERIFIED" ? "VERIFIED" : "UNVERIFIED";
export function decodeBoard(value: unknown): Board {
  const root = obj(value);
  const b = root.board === undefined ? root : obj(root.board);
  if (!Array.isArray(b.components) || !Array.isArray(b.nets))
    throw new Error("A board must contain components and nets arrays");
  let pinBudget = 20000;
  let pointBudget = 200000;
  const readPoints = (v: unknown): Point[] => {
    const result = points(v);
    pointBudget -= result.length;
    if (pointBudget < 0)
      throw new Error("Board exceeds total trace point limit");
    return result;
  };
  const components = list(b.components, 3000).map((value) => {
    const p = obj(value);
    const refDes = text(p.refDes).trim();
    if (!refDes || refDes.length > 80)
      throw new Error("Missing or invalid component reference");
    const pinSpecs = list(p.pinSpecs, 512).map((value) => {
      const pin = obj(value);
      const pinNumber = finite(pin.pinNumber, -1);
      if (!Number.isInteger(pinNumber) || pinNumber < 1)
        throw new Error(`Invalid pin number on ${refDes}`);
      return {
        pinNumber,
        pinName: text(pin.pinName, `PIN_${pinNumber}`),
        category: text(pin.category, "signal_in"),
        nominalVoltage: finite(pin.nominalVoltage),
        connectedNetId: normalizeNetName(text(pin.connectedNetId)),
        notes: text(pin.notes),
      };
    });
    pinBudget -= pinSpecs.length;
    if (pinBudget < 0) throw new Error("Board exceeds total pin limit");
    if (new Set(pinSpecs.map((p) => p.pinNumber)).size !== pinSpecs.length)
      throw new Error(`Duplicate pin number on ${refDes}`);
    return {
      refDes,
      bbox: box(p.bbox),
      pinSpecs,
      terminalIds: [] as string[],
      category: text(p.category, "UNKNOWN"),
      marking: text(p.marking),
      decodedValue: text(p.decodedValue),
      packageType: text(p.packageType),
      confidenceScore: clamp(finite(p.confidenceScore), 0, 1),
      verificationStatus: verification(p.verificationStatus),
      source: text(p.source, "IMPORTED"),
      notes: text(p.notes),
      circuitFunction: text(p.circuitFunction),
      operatingVoltageRange: text(p.operatingVoltageRange),
      datasheetSummary: text(p.datasheetSummary),
      maxCurrentRating: text(p.maxCurrentRating),
    };
  });
  if (new Set(components.map((p) => p.refDes)).size !== components.length)
    throw new Error("Duplicate component references");
  const nets = list(b.nets, 10000).map((value) => {
    const n = obj(value);
    return {
      name: normalizeNetName(text(n.name)),
      signalType: text(n.signalType, "SIGNAL_TRACE"),
      connectedComponentRefs: strings(n.connectedComponentRefs),
      connectedTerminalIds: strings(n.connectedTerminalIds),
      tracePoints: readPoints(n.tracePoints),
      traceBranches:
        n.traceBranches === undefined
          ? undefined
          : list(n.traceBranches, 1000).map(readPoints),
      nominalVoltage:
        typeof n.nominalVoltage === "number" &&
        Number.isFinite(n.nominalVoltage)
          ? n.nominalVoltage
          : undefined,
      confidenceScore: clamp(finite(n.confidenceScore), 0, 1),
      verificationStatus: verification(n.verificationStatus),
      isComplete: n.isComplete === true,
    };
  });
  if (new Set(nets.map((n) => n.name)).size !== nets.length)
    throw new Error("Duplicate normalized net names");
  const hotspots = list(b.hotspots, 3000).map((value, index) => {
    const h = obj(value);
    const severity: Severity =
      h.severity === "CRITICAL" || h.severity === "WARNING"
        ? h.severity
        : "INFO";
    return {
      id: text(h.id, `imported-${index}`),
      label: text(h.label, "Inspection region"),
      severity,
      bbox: box(h.bbox),
      suspectComponentRef: text(h.suspectComponentRef) || undefined,
      notes: text(h.notes),
      source: text(h.source, "IMPORTED"),
    };
  });
  if (new Set(hotspots.map((h) => h.id)).size !== hotspots.length)
    throw new Error("Duplicate hotspot IDs");
  return reconcileNets({
    id: text(b.id, "imported-board"),
    title: text(b.title ?? b.boardName ?? b.name, "Untitled PCB"),
    boardType: text(b.boardType ?? b.type, "PCB"),
    analysisSummary: text(b.analysisSummary ?? b.summary),
    model: text(b.model, "manual"),
    aspect: clamp(finite(b.aspect, 1.5), 0.1, 10),
    components,
    nets,
    hotspots,
  });
}
export function serializeBoard(board: Board): string {
  return JSON.stringify(
    { schemaVersion: 1, exportedAt: new Date().toISOString(), board },
    null,
    2,
  );
}
export function importBoard(json: string): Board {
  const raw: unknown = JSON.parse(json);
  const root = obj(raw);
  if (root.schemaVersion !== undefined && root.schemaVersion !== 1)
    throw new Error("Unsupported PCB schema version");
  return decodeBoard(raw);
}
export const EMPTY_BOARD: Board = {
  id: "blank",
  title: "Untitled PCB",
  boardType: "PCB",
  analysisSummary: "",
  model: "manual",
  aspect: 1.5,
  components: [],
  nets: [],
  hotspots: [],
};
