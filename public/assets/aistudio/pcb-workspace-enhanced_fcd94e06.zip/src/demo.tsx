import { StrictMode, useMemo } from "react";
import { createRoot } from "react-dom/client";
import { PcbWorkspace } from "./PcbWorkspace";
import { demoBoard } from "./demoBoard";
import type { PcbServices } from "./pcbServices";
function Demo() {
  const services = useMemo<PcbServices | undefined>(
    () =>
      new URLSearchParams(location.search).has("slow")
        ? {
            // Local test harness only. No analysis is performed and no image leaves the page.
            analyzeImage: async () => {
              await new Promise((resolve) => setTimeout(resolve, 800));
              return { ...demoBoard, title: "LATE RESULT MUST NOT APPEAR" };
            },
          }
        : undefined,
    [],
  );
  return (
    <div style={{ maxWidth: 1800, margin: "auto", padding: "20px 14px" }}>
      <p
        style={{
          color: "#91a6b7",
          fontSize: 12,
          margin: "0 0 12px",
          fontFamily: "system-ui",
        }}
      >
        INTERACTIVE REFERENCE · synthetic layout, not an OEM schematic · AI /
        cloud integrations are disabled in this demo
      </p>
      <PcbWorkspace
        initialBoard={demoBoard}
        presets={[{ board: demoBoard }]}
        services={services}
      />
    </div>
  );
}
const root = document.getElementById("root");
if (!root) throw new Error("Missing application root");
createRoot(root).render(
  <StrictMode>
    <Demo />
  </StrictMode>,
);
